// @bun
// src/triggers/core.ts
function trigger(init) {
  return { name: init.name, start: init.start };
}

// src/triggers/sources/cron.ts
var WEEKDAY_INDEX = {
  sun: 0,
  mon: 1,
  tue: 2,
  wed: 3,
  thu: 4,
  fri: 5,
  sat: 6
};
function utcDate(parts) {
  return new Date(Date.UTC(parts.year, parts.month, parts.day, parts.hour, parts.minute, 0, 0));
}
function nextRun(schedule, from) {
  const year = from.getUTCFullYear();
  const month = from.getUTCMonth();
  const day = from.getUTCDate();
  const hour = from.getUTCHours();
  const minute = from.getUTCMinutes();
  if (schedule.every === "minute") {
    return utcDate({ year, month, day, hour, minute: minute + 1 });
  }
  if (schedule.every === "hour") {
    const targetMinute2 = schedule.minute ?? 0;
    if (minute < targetMinute2) {
      return utcDate({ year, month, day, hour, minute: targetMinute2 });
    }
    return utcDate({ year, month, day, hour: hour + 1, minute: targetMinute2 });
  }
  if (schedule.every === "day") {
    const targetHour2 = schedule.at?.hour ?? 0;
    const targetMinute2 = schedule.at?.minute ?? 0;
    if (hour < targetHour2 || hour === targetHour2 && minute < targetMinute2) {
      return utcDate({
        year,
        month,
        day,
        hour: targetHour2,
        minute: targetMinute2
      });
    }
    return utcDate({
      year,
      month,
      day: day + 1,
      hour: targetHour2,
      minute: targetMinute2
    });
  }
  const weekdays = (Array.isArray(schedule.on) ? schedule.on : [schedule.on]).map((w) => WEEKDAY_INDEX[w]).sort((a, b) => a - b);
  const targetHour = schedule.at?.hour ?? 0;
  const targetMinute = schedule.at?.minute ?? 0;
  const currentWeekday = from.getUTCDay();
  for (let offset = 0;offset < 8; offset++) {
    const candidateWeekday = (currentWeekday + offset) % 7;
    if (!weekdays.includes(candidateWeekday))
      continue;
    const candidate = utcDate({
      year,
      month,
      day: day + offset,
      hour: targetHour,
      minute: targetMinute
    });
    if (candidate.getTime() > from.getTime())
      return candidate;
  }
  throw new Error("cron: failed to compute next run");
}
function cron(opts) {
  return {
    name: "cron",
    start: (emit) => {
      let stopped = false;
      let timer = null;
      function schedule() {
        if (stopped)
          return;
        const now = new Date;
        const next = nextRun(opts.schedule, now);
        const delay = Math.max(0, next.getTime() - now.getTime());
        timer = setTimeout(() => {
          if (stopped)
            return;
          emit({ firedAt: new Date });
          schedule();
        }, delay);
      }
      schedule();
      return () => {
        stopped = true;
        if (timer)
          clearTimeout(timer);
      };
    }
  };
}

// src/triggers/bus.ts
function makeBus() {
  return { subs: new Set };
}
function subscribe(bus, emit, filter) {
  const wrapped = filter ? (event) => {
    if (filter(event))
      emit(event);
  } : emit;
  bus.subs.add(wrapped);
  return () => {
    bus.subs.delete(wrapped);
  };
}
function dispatch(bus, event) {
  for (const sub of bus.subs)
    sub(event);
}

// src/triggers/sources/github.ts
var DEFAULT_DELIVERY_CACHE_SIZE = 1024;
function timingSafeEqual(a, b) {
  if (a.length !== b.length)
    return false;
  let diff = 0;
  for (let i = 0;i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}
async function verifySignature(secret, body, signatureHeader) {
  if (!signatureHeader)
    return false;
  const prefix = "sha256=";
  if (!signatureHeader.startsWith(prefix))
    return false;
  const provided = signatureHeader.slice(prefix.length).toLowerCase();
  if (!/^[0-9a-f]+$/.test(provided))
    return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const computedBytes = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body));
  const computed = Array.from(new Uint8Array(computedBytes)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return timingSafeEqual(provided, computed);
}

class DeliveryCache {
  seen = new Set;
  order = [];
  maxSize;
  constructor(maxSize) {
    this.maxSize = maxSize;
  }
  has(id) {
    return this.seen.has(id);
  }
  add(id) {
    if (this.seen.has(id))
      return;
    this.seen.add(id);
    this.order.push(id);
    while (this.order.length > this.maxSize) {
      const dropped = this.order.shift();
      if (dropped !== undefined)
        this.seen.delete(dropped);
    }
  }
}

class GithubReceiver {
  prBus = makeBus();
  issueCommentBus = makeBus();
  reviewCommentBus = makeBus();
  issuesBus = makeBus();
  pushBus = makeBus();
  secret;
  deliveries;
  constructor(options) {
    if (!options.secret) {
      throw new Error("GithubReceiver requires a non-empty secret");
    }
    this.secret = options.secret;
    this.deliveries = new DeliveryCache(options.deliveryCacheSize ?? DEFAULT_DELIVERY_CACHE_SIZE);
  }
  pullRequest(opts) {
    const bus = this.prBus;
    const actions = opts?.actions;
    return {
      name: "github:pull_request",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  issueComment(opts) {
    const bus = this.issueCommentBus;
    const actions = opts?.actions;
    return {
      name: "github:issue_comment",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  pullRequestReviewComment(opts) {
    const bus = this.reviewCommentBus;
    const actions = opts?.actions;
    return {
      name: "github:pull_request_review_comment",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  issues(opts) {
    const bus = this.issuesBus;
    const actions = opts?.actions;
    return {
      name: "github:issues",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  push() {
    const bus = this.pushBus;
    return {
      name: "github:push",
      start: (emit) => subscribe(bus, emit)
    };
  }
  handle = async (req) => {
    const eventType = req.headers.get("x-github-event");
    if (!eventType) {
      return new Response("missing x-github-event", { status: 400 });
    }
    const body = await req.text();
    const signatureValid = await verifySignature(this.secret, body, req.headers.get("x-hub-signature-256"));
    if (!signatureValid) {
      return new Response("invalid signature", { status: 401 });
    }
    const deliveryId = req.headers.get("x-github-delivery");
    if (deliveryId && this.deliveries.has(deliveryId)) {
      return new Response("duplicate", { status: 200 });
    }
    let payload;
    try {
      payload = JSON.parse(body);
    } catch {
      return new Response("invalid json", { status: 400 });
    }
    switch (eventType) {
      case "pull_request":
        dispatch(this.prBus, payload);
        break;
      case "issue_comment":
        dispatch(this.issueCommentBus, payload);
        break;
      case "pull_request_review_comment":
        dispatch(this.reviewCommentBus, payload);
        break;
      case "issues":
        dispatch(this.issuesBus, payload);
        break;
      case "push":
        dispatch(this.pushBus, payload);
        break;
      default:
        break;
    }
    if (deliveryId)
      this.deliveries.add(deliveryId);
    return new Response("ok", { status: 200 });
  };
}
function githubTrigger(options) {
  return new GithubReceiver(options);
}

// src/triggers/sources/grafana.ts
class GrafanaReceiver {
  alertBus = makeBus();
  alert(opts) {
    const bus = this.alertBus;
    const status = opts?.status;
    return {
      name: "grafana:alert",
      start: (emit) => subscribe(bus, emit, status ? (e) => e.status === status : undefined)
    };
  }
  handle = async (req) => {
    let payload;
    try {
      payload = await req.json();
    } catch {
      return new Response("invalid json", { status: 400 });
    }
    for (const alert of payload.alerts ?? []) {
      dispatch(this.alertBus, {
        ...alert,
        groupKey: payload.groupKey,
        externalURL: payload.externalURL
      });
    }
    return new Response("ok", { status: 200 });
  };
}
function grafanaTrigger() {
  return new GrafanaReceiver;
}

// src/triggers/sources/linear.ts
class LinearReceiver {
  issueBus = makeBus();
  commentBus = makeBus();
  projectBus = makeBus();
  issue(opts) {
    const bus = this.issueBus;
    const actions = opts?.actions;
    return {
      name: "linear:issue",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  comment(opts) {
    const bus = this.commentBus;
    const actions = opts?.actions;
    return {
      name: "linear:comment",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  project(opts) {
    const bus = this.projectBus;
    const actions = opts?.actions;
    return {
      name: "linear:project",
      start: (emit) => subscribe(bus, emit, actions ? (e) => actions.includes(e.action) : undefined)
    };
  }
  handle = async (req) => {
    let payload;
    try {
      payload = await req.json();
    } catch {
      return new Response("invalid json", { status: 400 });
    }
    switch (payload.type) {
      case "Issue":
        dispatch(this.issueBus, payload);
        break;
      case "Comment":
        dispatch(this.commentBus, payload);
        break;
      case "Project":
        dispatch(this.projectBus, payload);
        break;
      default:
        break;
    }
    return new Response("ok", { status: 200 });
  };
}
function linearTrigger() {
  return new LinearReceiver;
}

// src/triggers/sources/telegram.ts
var DEFAULT_UPDATE_CACHE_SIZE = 1024;
var TELEGRAM_API_BASE = "https://api.telegram.org";
var MAX_MESSAGE_LENGTH = 4096;
function timingSafeEqual2(a, b) {
  if (a.length !== b.length)
    return false;
  let diff = 0;
  for (let i = 0;i < a.length; i++) {
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return diff === 0;
}

class UpdateCache {
  seen = new Set;
  order = [];
  maxSize;
  constructor(maxSize) {
    this.maxSize = maxSize;
  }
  has(id) {
    return this.seen.has(id);
  }
  add(id) {
    if (this.seen.has(id))
      return;
    this.seen.add(id);
    this.order.push(id);
    while (this.order.length > this.maxSize) {
      const dropped = this.order.shift();
      if (dropped !== undefined)
        this.seen.delete(dropped);
    }
  }
}
function matchesCommand(message, commands, botUsername) {
  const text = message.text;
  if (!text || !text.startsWith("/"))
    return false;
  const token = text.slice(1).split(/\s/, 1)[0] ?? "";
  const [name, target] = token.split("@");
  if (target && botUsername) {
    const normalized = botUsername.replace(/^@/, "").toLowerCase();
    if (target.toLowerCase() !== normalized)
      return false;
  }
  return commands.some((command) => (command.startsWith("/") ? command.slice(1) : command) === name);
}

class TelegramReceiver {
  messageBus = makeBus();
  editedMessageBus = makeBus();
  secretToken;
  updates;
  constructor(options) {
    if (!options.secretToken) {
      throw new Error("TelegramReceiver requires a non-empty secretToken");
    }
    this.secretToken = options.secretToken;
    this.updates = new UpdateCache(options.updateCacheSize ?? DEFAULT_UPDATE_CACHE_SIZE);
  }
  message(opts) {
    const bus = this.messageBus;
    const commands = opts?.commands;
    const botUsername = opts?.botUsername;
    return {
      name: "telegram:message",
      start: (emit) => subscribe(bus, emit, commands ? (m) => matchesCommand(m, commands, botUsername) : undefined)
    };
  }
  editedMessage() {
    const bus = this.editedMessageBus;
    return {
      name: "telegram:edited_message",
      start: (emit) => subscribe(bus, emit)
    };
  }
  handle = async (req) => {
    const provided = req.headers.get("x-telegram-bot-api-secret-token");
    if (!provided || !timingSafeEqual2(provided, this.secretToken)) {
      return new Response("invalid secret token", { status: 401 });
    }
    let update;
    try {
      update = await req.json();
    } catch {
      return new Response("invalid json", { status: 400 });
    }
    if (typeof update.update_id !== "number") {
      return new Response("missing update_id", { status: 400 });
    }
    if (this.updates.has(update.update_id)) {
      return new Response("duplicate", { status: 200 });
    }
    if (update.message) {
      dispatch(this.messageBus, update.message);
    } else if (update.edited_message) {
      dispatch(this.editedMessageBus, update.edited_message);
    }
    this.updates.add(update.update_id);
    return new Response("ok", { status: 200 });
  };
}
function splitMessage(text, max = MAX_MESSAGE_LENGTH) {
  if (max < 1)
    throw new Error("splitMessage requires max >= 1");
  if (text.length <= max)
    return [text];
  const chunks = [];
  let remaining = text;
  while (remaining.length > max) {
    let cut = remaining.lastIndexOf(`
`, max);
    if (cut <= 0) {
      cut = max;
      const code = remaining.charCodeAt(cut - 1);
      if (code >= 55296 && code <= 56319)
        cut -= 1;
    }
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut).replace(/^\n/, "");
  }
  if (remaining.length > 0)
    chunks.push(remaining);
  return chunks;
}

class TelegramClient {
  token;
  baseUrl;
  constructor(token, opts) {
    if (!token)
      throw new Error("TelegramClient requires a bot token");
    this.token = token;
    this.baseUrl = (opts?.baseUrl ?? TELEGRAM_API_BASE).replace(/\/+$/, "");
  }
  async call(method, params) {
    const response = await fetch(`${this.baseUrl}/bot${this.token}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(params)
    });
    const data = await response.json();
    if (!data.ok) {
      throw new Error(`Telegram ${method} failed (${response.status}): ${data.description ?? "unknown error"}`);
    }
    return data.result;
  }
  getMe() {
    return this.call("getMe", {});
  }
  sendChatAction(chatId, action = "typing") {
    return this.call("sendChatAction", { chat_id: chatId, action });
  }
  async sendMessage(chatId, text, opts) {
    if (opts?.parseMode && text.length > MAX_MESSAGE_LENGTH) {
      throw new Error(`sendMessage: text exceeds ${MAX_MESSAGE_LENGTH} chars with parse_mode ${opts.parseMode}; auto-splitting could break entities. Split it yourself.`);
    }
    const sent = [];
    for (const chunk of splitMessage(text)) {
      sent.push(await this.call("sendMessage", {
        chat_id: chatId,
        text: chunk,
        ...opts?.parseMode ? { parse_mode: opts.parseMode } : {},
        ...opts?.replyToMessageId ? { reply_parameters: { message_id: opts.replyToMessageId } } : {},
        ...opts?.disableNotification ? { disable_notification: true } : {},
        ...opts?.linkPreview === false ? { link_preview_options: { is_disabled: true } } : {}
      }));
    }
    return sent;
  }
  editMessageText(chatId, messageId, text, opts) {
    return this.call("editMessageText", {
      chat_id: chatId,
      message_id: messageId,
      text,
      ...opts?.parseMode ? { parse_mode: opts.parseMode } : {}
    });
  }
  setWebhook(url, opts) {
    return this.call("setWebhook", {
      url,
      ...opts?.secretToken ? { secret_token: opts.secretToken } : {},
      ...opts?.allowedUpdates ? { allowed_updates: opts.allowedUpdates } : {}
    });
  }
  deleteWebhook(opts) {
    return this.call("deleteWebhook", {
      ...opts?.dropPendingUpdates ? { drop_pending_updates: true } : {}
    });
  }
}
function telegramTrigger(options) {
  return new TelegramReceiver(options);
}
export {
  trigger,
  telegramTrigger,
  splitMessage,
  linearTrigger,
  grafanaTrigger,
  githubTrigger,
  cron,
  TelegramReceiver,
  TelegramClient,
  LinearReceiver,
  GrafanaReceiver,
  GithubReceiver
};
