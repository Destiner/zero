import type { Emit, Unsub } from './core';
interface EventBus<T> {
    subs: Set<Emit<T>>;
}
declare function makeBus<T>(): EventBus<T>;
declare function subscribe<T>(bus: EventBus<T>, emit: Emit<T>, filter?: (event: T) => boolean): Unsub;
declare function dispatch<T>(bus: EventBus<T>, event: T): void;
export { dispatch, makeBus, subscribe, type EventBus };
