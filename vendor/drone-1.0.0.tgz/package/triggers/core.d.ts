type MaybePromise<T> = T | Promise<T>;
type Unsub = () => MaybePromise<void>;
type Emit<T> = (event: T) => void;
interface Trigger<T = unknown> {
    name: string;
    start(emit: Emit<T>): MaybePromise<Unsub>;
}
type TriggerHandler<T> = (event: T) => MaybePromise<void>;
interface CustomTriggerInit<T> {
    name: string;
    start: (emit: Emit<T>) => MaybePromise<Unsub>;
}
declare function trigger<T = unknown>(init: CustomTriggerInit<T>): Trigger<T>;
export { trigger, type Emit, type Trigger, type TriggerHandler, type Unsub };
