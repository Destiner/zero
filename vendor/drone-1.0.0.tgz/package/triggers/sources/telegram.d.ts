import type { Trigger } from '../core';
interface TelegramUser {
    id: number;
    is_bot: boolean;
    first_name: string;
    last_name?: string;
    username?: string;
    language_code?: string;
}
interface TelegramChat {
    id: number;
    type: 'private' | 'group' | 'supergroup' | 'channel';
    title?: string;
    username?: string;
    first_name?: string;
    last_name?: string;
}
interface TelegramMessage {
    message_id: number;
    from?: TelegramUser;
    chat: TelegramChat;
    date: number;
    text?: string;
    caption?: string;
    reply_to_message?: TelegramMessage;
}
interface TelegramUpdate {
    update_id: number;
    message?: TelegramMessage;
    edited_message?: TelegramMessage;
}
type TelegramChatAction = 'typing' | 'upload_photo' | 'record_video' | 'upload_video' | 'record_voice' | 'upload_voice' | 'upload_document' | 'choose_sticker' | 'find_location';
interface SendMessageOptions {
    parseMode?: 'MarkdownV2' | 'HTML';
    replyToMessageId?: number;
    disableNotification?: boolean;
    linkPreview?: boolean;
}
interface TelegramReceiverOptions {
    secretToken: string;
    updateCacheSize?: number;
}
declare class TelegramReceiver {
    private messageBus;
    private editedMessageBus;
    private readonly secretToken;
    private readonly updates;
    constructor(options: TelegramReceiverOptions);
    message(opts?: {
        commands?: string[];
        botUsername?: string;
    }): Trigger<TelegramMessage>;
    editedMessage(): Trigger<TelegramMessage>;
    handle: (req: Request) => Promise<Response>;
}
declare function splitMessage(text: string, max?: number): string[];
declare class TelegramClient {
    private readonly token;
    private readonly baseUrl;
    constructor(token: string, opts?: {
        baseUrl?: string;
    });
    private call;
    getMe(): Promise<TelegramUser>;
    sendChatAction(chatId: number | string, action?: TelegramChatAction): Promise<boolean>;
    sendMessage(chatId: number | string, text: string, opts?: SendMessageOptions): Promise<TelegramMessage[]>;
    editMessageText(chatId: number | string, messageId: number, text: string, opts?: {
        parseMode?: 'MarkdownV2' | 'HTML';
    }): Promise<TelegramMessage | boolean>;
    setWebhook(url: string, opts?: {
        secretToken?: string;
        allowedUpdates?: string[];
    }): Promise<boolean>;
    deleteWebhook(opts?: {
        dropPendingUpdates?: boolean;
    }): Promise<boolean>;
}
declare function telegramTrigger(options: TelegramReceiverOptions): TelegramReceiver;
export { telegramTrigger, TelegramClient, TelegramReceiver, splitMessage, type SendMessageOptions, type TelegramChat, type TelegramChatAction, type TelegramMessage, type TelegramReceiverOptions, type TelegramUpdate, type TelegramUser, };
