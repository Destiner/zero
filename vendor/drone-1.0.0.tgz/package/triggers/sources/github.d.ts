import type { Trigger } from '../core';
interface GithubUser {
    login: string;
    id: number;
    type: 'User' | 'Bot' | 'Organization' | string;
}
interface GithubRepository {
    id: number;
    name: string;
    full_name: string;
    owner: GithubUser;
    default_branch: string;
    private: boolean;
    html_url: string;
}
interface GithubLabel {
    id: number;
    name: string;
    color?: string;
}
interface GithubPullRef {
    ref: string;
    sha: string;
    repo: GithubRepository | null;
}
interface GithubPullRequest {
    number: number;
    state: 'open' | 'closed';
    title: string;
    body: string | null;
    draft: boolean;
    merged: boolean;
    head: GithubPullRef;
    base: GithubPullRef;
    user: GithubUser;
    labels: GithubLabel[];
    html_url: string;
}
interface GithubIssue {
    number: number;
    state: 'open' | 'closed';
    title: string;
    body: string | null;
    user: GithubUser;
    labels: GithubLabel[];
    pull_request?: {
        url: string;
    };
    html_url: string;
}
interface GithubComment {
    id: number;
    body: string;
    user: GithubUser;
    html_url: string;
}
interface GithubReviewComment extends GithubComment {
    path: string;
    line: number | null;
    start_line: number | null;
    commit_id: string;
    diff_hunk: string;
    pull_request_review_id: number | null;
    in_reply_to_id?: number;
}
interface GithubPushCommit {
    id: string;
    message: string;
    url: string;
    author: {
        name: string;
        email: string;
        username?: string;
    };
}
interface PullRequestEvent {
    action: string;
    number: number;
    pull_request: GithubPullRequest;
    repository: GithubRepository;
    sender: GithubUser;
}
interface IssuesEvent {
    action: string;
    issue: GithubIssue;
    repository: GithubRepository;
    sender: GithubUser;
}
interface IssueCommentEvent {
    action: string;
    issue: GithubIssue;
    comment: GithubComment;
    repository: GithubRepository;
    sender: GithubUser;
}
interface PullRequestReviewCommentEvent {
    action: string;
    comment: GithubReviewComment;
    pull_request: GithubPullRequest;
    repository: GithubRepository;
    sender: GithubUser;
}
interface PushEvent {
    ref: string;
    before: string;
    after: string;
    created: boolean;
    deleted: boolean;
    forced: boolean;
    commits: GithubPushCommit[];
    head_commit: GithubPushCommit | null;
    repository: GithubRepository;
    sender: GithubUser;
    pusher: {
        name: string;
        email: string;
    };
}
interface GithubReceiverOptions {
    secret: string;
    deliveryCacheSize?: number;
}
declare class GithubReceiver {
    private prBus;
    private issueCommentBus;
    private reviewCommentBus;
    private issuesBus;
    private pushBus;
    private readonly secret;
    private readonly deliveries;
    constructor(options: GithubReceiverOptions);
    pullRequest(opts?: {
        actions?: string[];
    }): Trigger<PullRequestEvent>;
    issueComment(opts?: {
        actions?: string[];
    }): Trigger<IssueCommentEvent>;
    pullRequestReviewComment(opts?: {
        actions?: string[];
    }): Trigger<PullRequestReviewCommentEvent>;
    issues(opts?: {
        actions?: string[];
    }): Trigger<IssuesEvent>;
    push(): Trigger<PushEvent>;
    handle: (req: Request) => Promise<Response>;
}
declare function githubTrigger(options: GithubReceiverOptions): GithubReceiver;
export { githubTrigger, GithubReceiver, type GithubComment, type GithubIssue, type GithubLabel, type GithubPullRef, type GithubPullRequest, type GithubPushCommit, type GithubReceiverOptions, type GithubRepository, type GithubReviewComment, type GithubUser, type IssueCommentEvent, type IssuesEvent, type PullRequestEvent, type PullRequestReviewCommentEvent, type PushEvent, };
