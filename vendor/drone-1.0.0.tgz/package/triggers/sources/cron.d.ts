import type { Trigger } from '../core';
type Weekday = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
type Schedule = {
    every: 'minute';
} | {
    every: 'hour';
    minute?: number;
} | {
    every: 'day';
    at?: {
        hour: number;
        minute?: number;
    };
} | {
    every: 'week';
    on: Weekday | Weekday[];
    at?: {
        hour: number;
        minute?: number;
    };
};
interface CronOptions {
    schedule: Schedule;
}
interface CronEvent {
    firedAt: Date;
}
declare function cron(opts: CronOptions): Trigger<CronEvent>;
export { cron, type CronEvent, type CronOptions, type Schedule, type Weekday };
