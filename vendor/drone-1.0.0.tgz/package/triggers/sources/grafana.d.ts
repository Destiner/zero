import type { Trigger } from '../core';
type Json = Record<string, unknown>;
type AlertStatus = 'firing' | 'resolved';
interface GrafanaAlert {
    status: AlertStatus;
    labels: Record<string, string>;
    annotations: Record<string, string>;
    startsAt: string;
    endsAt: string;
    generatorURL?: string;
    fingerprint?: string;
    values?: Json;
}
interface GrafanaAlertEvent extends GrafanaAlert {
    groupKey?: string;
    externalURL?: string;
}
interface GrafanaWebhookPayload {
    receiver?: string;
    status?: AlertStatus;
    alerts?: GrafanaAlert[];
    groupLabels?: Record<string, string>;
    commonLabels?: Record<string, string>;
    commonAnnotations?: Record<string, string>;
    externalURL?: string;
    version?: string;
    groupKey?: string;
}
declare class GrafanaReceiver {
    private alertBus;
    alert(opts?: {
        status?: AlertStatus;
    }): Trigger<GrafanaAlertEvent>;
    handle: (req: Request) => Promise<Response>;
}
declare function grafanaTrigger(): GrafanaReceiver;
export { grafanaTrigger, GrafanaReceiver, type AlertStatus, type GrafanaAlert, type GrafanaAlertEvent, type GrafanaWebhookPayload, };
