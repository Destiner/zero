import type { Trigger } from '../core';
type Json = Record<string, unknown>;
type LinearAction = 'create' | 'update' | 'remove';
interface LinearWebhook {
    action: LinearAction;
    type: string;
    data: Json;
    url?: string;
    createdAt?: string;
    organizationId?: string;
    webhookId?: string;
    webhookTimestamp?: number;
}
interface LinearIssueEvent extends LinearWebhook {
    type: 'Issue';
}
interface LinearCommentEvent extends LinearWebhook {
    type: 'Comment';
}
interface LinearProjectEvent extends LinearWebhook {
    type: 'Project';
}
declare class LinearReceiver {
    private issueBus;
    private commentBus;
    private projectBus;
    issue(opts?: {
        actions?: LinearAction[];
    }): Trigger<LinearIssueEvent>;
    comment(opts?: {
        actions?: LinearAction[];
    }): Trigger<LinearCommentEvent>;
    project(opts?: {
        actions?: LinearAction[];
    }): Trigger<LinearProjectEvent>;
    handle: (req: Request) => Promise<Response>;
}
declare function linearTrigger(): LinearReceiver;
export { linearTrigger, LinearReceiver, type LinearAction, type LinearCommentEvent, type LinearIssueEvent, type LinearProjectEvent, type LinearWebhook, };
