// @bun
// src/core/agent.ts
import { z as z2 } from "zod";

// src/core/session.ts
class Turn {
  queue = [];
  waiters = [];
  ended = false;
  iterated = false;
  resultPromise;
  abortController = new AbortController;
  constructor(runner) {
    this.resultPromise = runner({
      emit: (event) => this.emit(event),
      signal: this.abortController.signal
    }).then((messages) => {
      this.close();
      return messages;
    }, (error) => {
      this.close();
      throw error;
    });
    this.resultPromise.catch(() => {});
  }
  emit(event) {
    const waiter = this.waiters.shift();
    if (waiter) {
      waiter({ value: event, done: false });
    } else {
      this.queue.push(event);
    }
  }
  close() {
    this.ended = true;
    while (this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      waiter?.({ value: undefined, done: true });
    }
  }
  abort(reason) {
    this.abortController.abort(reason);
  }
  [Symbol.asyncIterator]() {
    if (this.iterated) {
      throw new Error("Turn can only be iterated once.");
    }
    this.iterated = true;
    return {
      next: () => {
        if (this.queue.length > 0) {
          const value = this.queue.shift();
          return Promise.resolve({ value, done: false });
        }
        if (this.ended) {
          return Promise.resolve({
            value: undefined,
            done: true
          });
        }
        return new Promise((resolve) => this.waiters.push(resolve));
      },
      return: async () => {
        this.abort("iteration ended");
        await this.resultPromise.catch(() => {});
        return {
          value: undefined,
          done: true
        };
      }
    };
  }
  then(onfulfilled, onrejected) {
    return this.resultPromise.then(onfulfilled, onrejected);
  }
}

class Session {
  internals;
  state;
  constructor(internals, state) {
    this.internals = internals;
    this.state = state;
  }
  get messages() {
    return this.state.messages;
  }
  send(prompt) {
    return this.internals.send(prompt);
  }
  async close() {
    await this.internals.close();
  }
  async[Symbol.asyncDispose]() {
    await this.close();
  }
}

// src/core/tool.ts
import { z } from "zod";

class Tool {
  name;
  description;
  inputSchema;
  jsonSchema;
  execute;
  deferred;
  constructor(init) {
    this.name = init.name;
    this.description = init.description;
    this.deferred = init.deferred ?? false;
    if ("inputSchema" in init) {
      this.inputSchema = init.inputSchema;
      this.execute = init.execute;
    } else {
      this.jsonSchema = init.jsonSchema;
      this.execute = init.execute;
    }
  }
  toJsonSchema() {
    if (this.jsonSchema !== undefined)
      return this.jsonSchema;
    if (this.inputSchema === undefined) {
      throw new Error(`Tool "${this.name}" has neither inputSchema nor jsonSchema.`);
    }
    return z.toJSONSchema(this.inputSchema);
  }
  parse(input) {
    if (this.inputSchema)
      return this.inputSchema.parse(input);
    return input;
  }
}
function createRegistry(tools) {
  const byName = new Map(tools.map((tool) => [tool.name, tool]));
  const loadedNames = new Set(tools.filter((tool) => !tool.deferred).map((tool) => tool.name));
  return {
    loaded: () => tools.filter((tool) => loadedNames.has(tool.name)),
    deferred: () => tools.filter((tool) => tool.deferred && !loadedNames.has(tool.name)),
    load: (names) => {
      const loaded = [];
      const missing = [];
      for (const name of names) {
        const tool = byName.get(name);
        if (!tool) {
          missing.push(name);
          continue;
        }
        loadedNames.add(name);
        loaded.push(tool);
      }
      return { loaded, missing };
    }
  };
}

// src/core/agent.ts
class Agent {
  model;
  prompt;
  tools;
  skills;
  mcp;
  cwd;
  registrations = [];
  unsubs = [];
  constructor({
    model,
    prompt,
    tools,
    skills,
    mcp,
    cwd
  }) {
    this.model = model;
    this.prompt = prompt;
    this.tools = tools;
    this.skills = skills;
    this.mcp = mcp ?? [];
    this.cwd = cwd;
  }
  on(trigger, handler) {
    this.registrations.push({ trigger, handler });
  }
  async start() {
    for (const { trigger, handler } of this.registrations) {
      const unsub = await trigger.start((event) => {
        Promise.resolve().then(() => handler(event)).catch((error) => {
          const message = error instanceof Error ? error.message : String(error);
          console.error(`[drone] trigger "${trigger.name}" handler failed: ${message}`);
        });
      });
      this.unsubs.push(unsub);
    }
  }
  async stop() {
    const unsubs = this.unsubs;
    this.unsubs = [];
    await Promise.all(unsubs.map((u) => u()));
  }
  buildSystem(allTools) {
    let system = this.prompt;
    if (this.skills.length > 0) {
      const skillsList = this.skills.map((skill) => `- ${skill.name}: ${skill.description}`).join(`
`);
      system = `${system}

# Skills
The following skills are available. When a task matches one, call the \`Skill\` tool with that skill's name to load its full content before proceeding.

${skillsList}`;
    }
    const deferred = allTools.filter((tool) => tool.deferred);
    if (deferred.length > 0) {
      const list = deferred.map((tool) => `- ${tool.name}`).join(`
`);
      system = `${system}

# Deferred tools
These tools are available but their schemas are not loaded. Use ToolSearch to load them before calling.
${list}`;
    }
    return system;
  }
  buildSkillTool() {
    const byName = new Map(this.skills.map((skill) => [skill.name, skill]));
    return new Tool({
      name: "Skill",
      description: 'Load the full content of a skill listed under "# Skills" in the system prompt. Call this when you decide a listed skill applies to the current task; the returned content extends your instructions for the rest of the session.',
      inputSchema: z2.object({
        skill: z2.string().describe("Name of the skill to load (must match a listed skill).")
      }),
      execute: ({ skill }) => {
        const found = byName.get(skill);
        if (!found) {
          const available = [...byName.keys()].join(", ");
          throw new Error(`Skill "${skill}" not found. Available: ${available}`);
        }
        return `<skill name="${found.name}">
${found.content}
</skill>`;
      }
    });
  }
  session(init) {
    const initialMessages = init?.messages ? [...init.messages] : [];
    const sessionCwd = init?.cwd ?? this.cwd ?? process.cwd();
    const state = {
      messages: initialMessages,
      store: new Map
    };
    let activeTurn = null;
    let mcpConnected = false;
    let allTools = null;
    let registry = null;
    let ctx = null;
    const ensureReady = async () => {
      if (!allTools || !registry || !ctx) {
        const mcpToolGroups = await Promise.all(this.mcp.map((mcp) => mcp.connect()));
        mcpConnected = true;
        allTools = [
          ...this.tools,
          ...mcpToolGroups.flat(),
          ...this.skills.length > 0 ? [this.buildSkillTool()] : []
        ];
        registry = createRegistry(allTools);
        ctx = {
          complete: async (p) => {
            const response = await this.model.createMessage({
              messages: [{ role: "user", content: p }]
            });
            return response.content.filter((block) => block.type === "text").map((block) => block.text).join(`
`);
          },
          searchWeb: (query, opts) => this.model.searchWeb(query, opts),
          session: state,
          tools: registry,
          cwd: sessionCwd
        };
        if (state.messages.length === 0 || state.messages[0]?.role !== "system") {
          state.messages.unshift({
            role: "system",
            content: this.buildSystem(allTools)
          });
        }
      }
      return { tools: allTools, registry, ctx };
    };
    const internals = {
      send: (prompt) => {
        if (activeTurn !== null) {
          throw new Error("Session.send() called while another turn is in flight.");
        }
        const turn = new Turn(async (turnCtx) => {
          try {
            const ready = await ensureReady();
            state.messages.push(toUserMessage(prompt));
            await runAgentLoop({
              model: this.model,
              state,
              registry: ready.registry,
              ctx: ready.ctx,
              emit: turnCtx.emit,
              signal: turnCtx.signal
            });
            return [...state.messages];
          } finally {
            activeTurn = null;
          }
        });
        activeTurn = turn;
        return turn;
      },
      close: async () => {
        const pending = activeTurn;
        if (pending) {
          pending.abort("session closed");
          await Promise.resolve(pending).catch(() => {});
        }
        if (mcpConnected) {
          await Promise.all(this.mcp.map((mcp) => mcp.disconnect()));
          mcpConnected = false;
        }
      }
    };
    return new Session(internals, state);
  }
}
function toUserMessage(prompt) {
  if (typeof prompt === "string")
    return { role: "user", content: prompt };
  return { role: "user", content: prompt };
}
async function runAgentLoop({
  model,
  state,
  registry,
  ctx,
  emit,
  signal
}) {
  while (true) {
    if (signal.aborted)
      break;
    const active = registry.loaded();
    const toolByName = new Map(active.map((tool) => [tool.name, tool]));
    emit({ type: "message-start" });
    const assistantContent = [];
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    try {
      for await (const event of model.streamMessage({
        messages: state.messages,
        tools: active,
        signal
      })) {
        switch (event.type) {
          case "text-delta":
            emit({ type: "text-delta", text: event.text });
            break;
          case "text-end":
            assistantContent.push({ type: "text", text: event.text });
            emit({ type: "text", text: event.text });
            break;
          case "thinking-delta":
            emit({ type: "thinking-delta", text: event.text });
            break;
          case "thinking-end":
            assistantContent.push({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {},
              ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
            });
            emit({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {}
            });
            break;
          case "tool-call":
            assistantContent.push({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            emit({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            break;
          case "message-end":
            stopReason = event.stopReason;
            usage = event.usage;
            break;
          default:
            break;
        }
      }
    } catch (error) {
      if (signal.aborted) {
        state.messages.push({ role: "assistant", content: assistantContent });
        break;
      }
      const err = error instanceof Error ? error : new Error(String(error));
      emit({ type: "error", error: err });
      throw err;
    }
    state.messages.push({ role: "assistant", content: assistantContent });
    emit({ type: "message-end", usage });
    if (stopReason !== "tool_use") {
      emit({ type: "turn-end" });
      break;
    }
    const toolCalls = assistantContent.filter((block) => block.type === "tool-call");
    const results = [];
    for (const call of toolCalls) {
      if (signal.aborted)
        break;
      const tool = toolByName.get(call.toolName);
      const result = await runTool(tool, call, ctx);
      results.push(result);
      emit({
        type: "tool-result",
        toolCallId: result.toolCallId,
        toolName: result.toolName,
        output: result.output,
        isError: typeof result.output === "string" ? result.output.startsWith("Error:") : false
      });
    }
    state.messages.push({ role: "tool", content: results });
    if (signal.aborted)
      break;
  }
}
async function runTool(tool, call, ctx) {
  if (!tool) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: tool "${call.toolName}" not found`
    };
  }
  try {
    const parsed = tool.parse(call.input);
    const output = await tool.execute(parsed, ctx);
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output
    };
  } catch (error) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}

// src/core/model.ts
class Model {
  async createMessage(params) {
    const content = [];
    let id = "";
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    for await (const event of this.streamMessage(params)) {
      switch (event.type) {
        case "text-end":
          content.push({ type: "text", text: event.text });
          break;
        case "thinking-end":
          content.push({
            type: "thinking",
            text: event.text,
            ...event.signature !== undefined ? { signature: event.signature } : {},
            ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
          });
          break;
        case "tool-call":
          content.push({
            type: "tool-call",
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            input: event.input
          });
          break;
        case "message-end":
          id = event.id;
          stopReason = event.stopReason;
          usage = event.usage;
          break;
        default:
          break;
      }
    }
    return { id, content, stopReason, usage };
  }
}

// src/core/skill.ts
class Skill {
  name;
  description;
  content;
  constructor({
    name,
    description,
    content
  }) {
    this.name = name;
    this.description = description;
    this.content = content;
  }
}

// src/mcp/oauth.ts
function base64UrlEncode(bytes) {
  let str = "";
  for (const byte of bytes)
    str += String.fromCharCode(byte);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function randomBytes(length) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}
async function sha256(input) {
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return new Uint8Array(hash);
}
async function generatePkce() {
  const verifier = base64UrlEncode(randomBytes(32));
  const challenge = base64UrlEncode(await sha256(verifier));
  return { verifier, challenge };
}
function generateState() {
  return base64UrlEncode(randomBytes(16));
}
async function discover(serverUrl) {
  const u = new URL(serverUrl);
  const origin = `${u.protocol}//${u.host}`;
  let authServer = origin;
  try {
    const res2 = await fetch(`${origin}/.well-known/oauth-protected-resource`);
    if (res2.ok) {
      const meta = await res2.json();
      if (meta.authorization_servers?.[0])
        authServer = meta.authorization_servers[0];
    }
  } catch {}
  const asUrl = new URL(authServer);
  const asOrigin = `${asUrl.protocol}//${asUrl.host}`;
  const res = await fetch(`${asOrigin}/.well-known/oauth-authorization-server`);
  if (!res.ok) {
    throw new Error(`OAuth discovery failed for ${asOrigin}: ${res.status} ${await res.text()}`);
  }
  return await res.json();
}
async function registerClient(registrationEndpoint, redirectUri) {
  const res = await fetch(registrationEndpoint, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      client_name: "drone",
      redirect_uris: [redirectUri],
      grant_types: ["authorization_code", "refresh_token"],
      response_types: ["code"],
      token_endpoint_auth_method: "none"
    })
  });
  if (!res.ok) {
    throw new Error(`OAuth client registration failed: ${res.status} ${await res.text()}`);
  }
  const data = await res.json();
  return data.client_id;
}
function openBrowser(url) {
  const cmd = process.platform === "darwin" ? "open" : process.platform === "win32" ? "start" : "xdg-open";
  Bun.spawn([cmd, url], { stdout: "ignore", stderr: "ignore" });
}
function captureAuthorizationCode(port, expectedState, timeoutMs) {
  return new Promise((resolve, reject) => {
    const server = Bun.serve({
      port,
      hostname: "127.0.0.1",
      fetch(req) {
        const u = new URL(req.url);
        const error = u.searchParams.get("error");
        if (error) {
          const desc = u.searchParams.get("error_description") ?? "";
          finish(() => reject(new Error(`OAuth error: ${error} ${desc}`)));
          return new Response("Authentication failed. You can close this tab.", {
            status: 400
          });
        }
        const code = u.searchParams.get("code");
        const state = u.searchParams.get("state");
        if (!code || state !== expectedState) {
          finish(() => reject(new Error("OAuth state mismatch or missing code.")));
          return new Response("Invalid OAuth response.", { status: 400 });
        }
        finish(() => resolve(code));
        return new Response("<html><body>Authenticated. You can close this tab.</body></html>", { headers: { "content-type": "text/html" } });
      }
    });
    const timer = setTimeout(() => {
      finish(() => reject(new Error("OAuth flow timed out.")));
    }, timeoutMs);
    function finish(action) {
      clearTimeout(timer);
      setTimeout(() => server.stop(true), 50);
      action();
    }
  });
}
async function exchangeCode(opts) {
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code: opts.code,
    redirect_uri: opts.redirectUri,
    client_id: opts.clientId,
    code_verifier: opts.verifier
  });
  const res = await fetch(opts.tokenEndpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body
  });
  if (!res.ok) {
    throw new Error(`OAuth token exchange failed: ${res.status} ${await res.text()}`);
  }
  return await res.json();
}
async function refreshTokens(opts) {
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: opts.refreshToken,
    client_id: opts.clientId
  });
  const res = await fetch(opts.tokenEndpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body
  });
  if (!res.ok) {
    throw new Error(`OAuth refresh failed: ${res.status} ${await res.text()}`);
  }
  return await res.json();
}

// src/mcp/storage.ts
import { chmod, mkdir, readFile, writeFile } from "fs/promises";
import { homedir } from "os";
import { dirname, join } from "path";
var DEFAULT_PATH = join(homedir(), ".drone", "mcp-auth.json");

class FileStorage {
  path;
  cache;
  constructor(path) {
    this.path = path ?? DEFAULT_PATH;
  }
  async read() {
    if (this.cache)
      return this.cache;
    try {
      const raw = await readFile(this.path, "utf8");
      this.cache = JSON.parse(raw);
    } catch {
      this.cache = {};
    }
    return this.cache;
  }
  async write(data) {
    await mkdir(dirname(this.path), { recursive: true });
    await writeFile(this.path, JSON.stringify(data, null, 2), "utf8");
    await chmod(this.path, 384);
    this.cache = data;
  }
  async load(key) {
    const data = await this.read();
    return data[key] ?? null;
  }
  async save(key, tokens) {
    const data = await this.read();
    data[key] = tokens;
    await this.write(data);
  }
  async clear(key) {
    const data = await this.read();
    delete data[key];
    await this.write(data);
  }
}

class MemoryStorage {
  data = new Map;
  async load(key) {
    return this.data.get(key) ?? null;
  }
  async save(key, tokens) {
    this.data.set(key, tokens);
  }
  async clear(key) {
    this.data.delete(key);
  }
}

// src/mcp/auth.ts
class BearerAuth {
  token;
  constructor(token) {
    this.token = token;
  }
  async getHeader() {
    return `Bearer ${this.token}`;
  }
}
var DEFAULT_PORT = 33418;
var DEFAULT_TIMEOUT_MS = 5 * 60 * 1000;

class OAuthAuth {
  serverUrl;
  storage;
  storageKey;
  redirectPort;
  scopes;
  flowTimeoutMs;
  tokens;
  loaded = false;
  metadata;
  inFlight;
  constructor(opts) {
    this.serverUrl = opts.serverUrl;
    this.storage = opts.storage ?? new FileStorage;
    this.storageKey = opts.storageKey;
    this.redirectPort = opts.redirectPort ?? DEFAULT_PORT;
    this.scopes = opts.scopes;
    this.flowTimeoutMs = opts.flowTimeoutMs ?? DEFAULT_TIMEOUT_MS;
  }
  async getHeader() {
    await this.ensureTokens();
    if (!this.tokens)
      throw new Error("OAuth: no tokens after auth flow.");
    return `Bearer ${this.tokens.accessToken}`;
  }
  async onUnauthorized() {
    if (this.tokens?.refreshToken) {
      try {
        await this.refresh();
        return;
      } catch {}
    }
    this.tokens = undefined;
    await this.storage.clear(this.storageKey);
    await this.authorize();
  }
  async ensureTokens() {
    if (this.inFlight) {
      await this.inFlight;
      return;
    }
    this.inFlight = (async () => {
      if (!this.loaded) {
        this.tokens = await this.storage.load(this.storageKey) ?? undefined;
        this.loaded = true;
      }
      if (!this.tokens) {
        await this.authorize();
        return;
      }
      if (this.isExpired(this.tokens)) {
        if (this.tokens.refreshToken) {
          try {
            await this.refresh();
            return;
          } catch {}
        }
        await this.authorize();
      }
    })();
    try {
      await this.inFlight;
    } finally {
      this.inFlight = undefined;
    }
  }
  isExpired(tokens) {
    if (!tokens.expiresAt)
      return false;
    return Date.now() / 1000 >= tokens.expiresAt - 30;
  }
  async getMetadata() {
    if (!this.metadata)
      this.metadata = await discover(this.serverUrl);
    return this.metadata;
  }
  async authorize() {
    const meta = await this.getMetadata();
    const redirectUri = this.tokens?.redirectUri ?? `http://127.0.0.1:${this.redirectPort}/callback`;
    let clientId = this.tokens?.clientId;
    if (!clientId) {
      if (!meta.registration_endpoint) {
        throw new Error("OAuth server does not support dynamic client registration; provide a client_id manually.");
      }
      clientId = await registerClient(meta.registration_endpoint, redirectUri);
    }
    const { verifier, challenge } = await generatePkce();
    const state = generateState();
    const port = parseInt(new URL(redirectUri).port, 10);
    const codePromise = captureAuthorizationCode(port, state, this.flowTimeoutMs);
    const authUrl = new URL(meta.authorization_endpoint);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("client_id", clientId);
    authUrl.searchParams.set("redirect_uri", redirectUri);
    authUrl.searchParams.set("code_challenge", challenge);
    authUrl.searchParams.set("code_challenge_method", "S256");
    authUrl.searchParams.set("state", state);
    if (this.scopes?.length) {
      authUrl.searchParams.set("scope", this.scopes.join(" "));
    }
    console.error(`[mcp:oauth] Opening browser for ${this.storageKey} authentication...`);
    openBrowser(authUrl.toString());
    const code = await codePromise;
    const response = await exchangeCode({
      tokenEndpoint: meta.token_endpoint,
      code,
      clientId,
      redirectUri,
      verifier
    });
    this.tokens = this.toTokenSet(response, clientId, redirectUri);
    await this.storage.save(this.storageKey, this.tokens);
  }
  async refresh() {
    if (!this.tokens?.refreshToken || !this.tokens.clientId) {
      throw new Error("OAuth refresh: missing refresh token or client id.");
    }
    const meta = await this.getMetadata();
    const response = await refreshTokens({
      tokenEndpoint: meta.token_endpoint,
      refreshToken: this.tokens.refreshToken,
      clientId: this.tokens.clientId
    });
    this.tokens = this.toTokenSet(response, this.tokens.clientId, this.tokens.redirectUri, this.tokens.refreshToken);
    await this.storage.save(this.storageKey, this.tokens);
  }
  toTokenSet(response, clientId, redirectUri, fallbackRefresh) {
    const expiresAt = response.expires_in ? Math.floor(Date.now() / 1000) + response.expires_in : undefined;
    return {
      accessToken: response.access_token,
      refreshToken: response.refresh_token ?? fallbackRefresh,
      expiresAt,
      clientId,
      redirectUri
    };
  }
}

// src/mcp/clients/grafana.ts
var EMPTY_OBJECT = {
  type: "object",
  properties: {},
  additionalProperties: false
};
var TOOLS = [
  {
    name: "list_datasources",
    description: "List all configured Grafana datasources.",
    inputSchema: EMPTY_OBJECT,
    call: (_, ctx) => request(ctx, "GET", "/api/datasources")
  },
  {
    name: "get_datasource",
    description: "Fetch a single datasource by UID.",
    inputSchema: {
      type: "object",
      properties: {
        uid: { type: "string", description: "Datasource UID." }
      },
      required: ["uid"],
      additionalProperties: false
    },
    call: (args, ctx) => request(ctx, "GET", `/api/datasources/uid/${encodeURIComponent(String(args.uid))}`)
  },
  {
    name: "query",
    description: "Run one or more queries against Grafana datasources via /api/ds/query. Pass the query array as Grafana expects (each item needs refId and datasource.uid).",
    inputSchema: {
      type: "object",
      properties: {
        queries: {
          type: "array",
          description: "Array of query objects (refId, datasource, expr/range/etc.).",
          items: { type: "object" }
        },
        from: {
          type: "string",
          description: 'Range start, e.g. "now-1h" or epoch ms as string.'
        },
        to: {
          type: "string",
          description: 'Range end, e.g. "now" or epoch ms as string.'
        }
      },
      required: ["queries"],
      additionalProperties: false
    },
    call: (args, ctx) => request(ctx, "POST", "/api/ds/query", {
      queries: args.queries,
      from: args.from ?? "now-1h",
      to: args.to ?? "now"
    })
  },
  {
    name: "search_dashboards",
    description: "Search dashboards by name, tag, or folder.",
    inputSchema: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "Substring match on dashboard title."
        },
        tag: {
          type: "array",
          items: { type: "string" },
          description: "Filter by tags."
        },
        folderUIDs: {
          type: "array",
          items: { type: "string" },
          description: "Limit to specific folder UIDs."
        },
        limit: { type: "number", description: "Max results (default 100)." }
      },
      additionalProperties: false
    },
    call: (args, ctx) => {
      const params = new URLSearchParams;
      params.set("type", "dash-db");
      if (typeof args.query === "string")
        params.set("query", args.query);
      if (typeof args.limit === "number")
        params.set("limit", String(args.limit));
      for (const tag of args.tag ?? [])
        params.append("tag", tag);
      for (const uid of args.folderUIDs ?? [])
        params.append("folderUIDs", uid);
      return request(ctx, "GET", `/api/search?${params.toString()}`);
    }
  },
  {
    name: "get_dashboard",
    description: "Fetch a dashboard JSON by UID.",
    inputSchema: {
      type: "object",
      properties: {
        uid: { type: "string", description: "Dashboard UID." }
      },
      required: ["uid"],
      additionalProperties: false
    },
    call: (args, ctx) => request(ctx, "GET", `/api/dashboards/uid/${encodeURIComponent(String(args.uid))}`)
  },
  {
    name: "list_folders",
    description: "List dashboard folders.",
    inputSchema: EMPTY_OBJECT,
    call: (_, ctx) => request(ctx, "GET", "/api/folders")
  },
  {
    name: "list_alert_rules",
    description: "List provisioned alert rules.",
    inputSchema: EMPTY_OBJECT,
    call: (_, ctx) => request(ctx, "GET", "/api/v1/provisioning/alert-rules")
  }
];
async function request(ctx, method, path, body) {
  const headers = {
    accept: "application/json",
    authorization: await ctx.auth.getHeader()
  };
  if (body !== undefined)
    headers["content-type"] = "application/json";
  const res = await fetch(`${ctx.baseUrl}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Grafana ${method} ${path} failed: ${res.status} ${text}`);
  }
  if (!text)
    return null;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

class Mcp {
  baseUrl;
  auth;
  nameSpace;
  deferred;
  constructor(opts) {
    this.baseUrl = opts.url.replace(/\/$/, "");
    this.auth = new BearerAuth(opts.serviceAccountToken);
    this.nameSpace = opts.name ?? "grafana";
    this.deferred = opts.deferred ?? true;
  }
  async connect() {
    const ctx = { baseUrl: this.baseUrl, auth: this.auth };
    return TOOLS.map((def) => new Tool({
      name: `mcp__${this.nameSpace}__${def.name}`,
      description: def.description,
      jsonSchema: def.inputSchema,
      deferred: this.deferred,
      execute: async (input) => {
        const args = input ?? {};
        const result = await def.call(args, ctx);
        return typeof result === "string" ? result : JSON.stringify(result);
      }
    }));
  }
  async disconnect() {}
}
var grafana_default = Mcp;

// src/mcp/core.ts
var PROTOCOL_VERSION = "2024-11-05";

class StdioTransport {
  config;
  proc;
  nextId = 1;
  pending = new Map;
  buffer = "";
  constructor(config) {
    this.config = config;
  }
  async start() {
    this.proc = Bun.spawn([this.config.command, ...this.config.args ?? []], {
      stdin: "pipe",
      stdout: "pipe",
      stderr: "inherit",
      env: { ...process.env, ...this.config.env }
    });
    this.readLoop();
  }
  async readLoop() {
    if (!this.proc?.stdout)
      return;
    const reader = this.proc.stdout.getReader();
    const decoder = new TextDecoder;
    while (true) {
      const { value, done } = await reader.read();
      if (done)
        break;
      this.buffer += decoder.decode(value, { stream: true });
      let idx = this.buffer.indexOf(`
`);
      while (idx !== -1) {
        const line = this.buffer.slice(0, idx).trim();
        this.buffer = this.buffer.slice(idx + 1);
        if (line)
          this.handleLine(line);
        idx = this.buffer.indexOf(`
`);
      }
    }
    for (const { reject } of this.pending.values()) {
      reject(new Error("MCP stdio transport closed."));
    }
    this.pending.clear();
  }
  handleLine(line) {
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      return;
    }
    if (msg.id === null || msg.id === undefined)
      return;
    const id = typeof msg.id === "string" ? parseInt(msg.id, 10) : msg.id;
    const pending = this.pending.get(id);
    if (!pending)
      return;
    this.pending.delete(id);
    if (msg.error) {
      pending.reject(new Error(`MCP error ${msg.error.code}: ${msg.error.message}`));
    } else {
      pending.resolve(msg.result);
    }
  }
  async stop() {
    this.proc?.kill();
    if (this.proc)
      await this.proc.exited;
    this.proc = undefined;
  }
  writeLine(line) {
    const sink = this.proc?.stdin;
    if (!sink || typeof sink === "number") {
      throw new Error("MCP stdio transport not started.");
    }
    sink.write(`${line}
`);
    sink.flush();
  }
  async request(method, params) {
    const id = this.nextId++;
    const req = { jsonrpc: "2.0", id, method, params };
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try {
        this.writeLine(JSON.stringify(req));
      } catch (error) {
        this.pending.delete(id);
        reject(error);
      }
    });
  }
  async notify(method, params) {
    const req = { jsonrpc: "2.0", method, params };
    this.writeLine(JSON.stringify(req));
  }
}

class HttpTransport {
  config;
  nextId = 1;
  sessionId;
  constructor(config) {
    this.config = config;
  }
  async start() {}
  async stop() {}
  async buildHeaders() {
    const headers = {
      "content-type": "application/json",
      accept: "application/json, text/event-stream",
      ...this.config.headers ?? {}
    };
    if (this.sessionId)
      headers["mcp-session-id"] = this.sessionId;
    if (this.config.auth) {
      headers["authorization"] = await this.config.auth.getHeader();
    }
    return headers;
  }
  async send(body, expectId) {
    const res = await this.attempt(body);
    if (res.status === 401 && this.config.auth?.onUnauthorized) {
      await res.body?.cancel();
      await this.config.auth.onUnauthorized();
      const retried = await this.attempt(body);
      return this.consume(retried, expectId);
    }
    return this.consume(res, expectId);
  }
  async attempt(body) {
    return fetch(this.config.url, {
      method: "POST",
      headers: await this.buildHeaders(),
      body: JSON.stringify(body)
    });
  }
  async consume(res, expectId) {
    if (!res.ok) {
      throw new Error(`MCP HTTP error ${res.status}: ${await res.text()}`);
    }
    const sid = res.headers.get("mcp-session-id");
    if (sid)
      this.sessionId = sid;
    if (expectId === undefined) {
      await res.body?.cancel();
      return;
    }
    const contentType = res.headers.get("content-type") ?? "";
    if (contentType.includes("text/event-stream")) {
      return this.readSseResponse(res, expectId);
    }
    const json = await res.json();
    return this.unwrap(json, expectId);
  }
  async readSseResponse(res, expectId) {
    const text = await res.text();
    for (const block of text.split(/\n\n+/)) {
      const dataLines = block.split(`
`).filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trimStart());
      if (dataLines.length === 0)
        continue;
      const payload = dataLines.join(`
`);
      let json;
      try {
        json = JSON.parse(payload);
      } catch {
        continue;
      }
      const id = typeof json.id === "string" ? parseInt(json.id, 10) : json.id;
      if (id === expectId)
        return this.unwrap(json, expectId);
    }
    throw new Error("MCP HTTP SSE response missing expected id.");
  }
  unwrap(json, expectId) {
    if (json.error) {
      throw new Error(`MCP error ${json.error.code}: ${json.error.message}`);
    }
    const id = typeof json.id === "string" ? parseInt(json.id, 10) : json.id;
    if (id !== expectId) {
      throw new Error(`MCP HTTP response id mismatch (got ${id}).`);
    }
    return json.result;
  }
  async request(method, params) {
    const id = this.nextId++;
    const req = { jsonrpc: "2.0", id, method, params };
    return this.send(req, id);
  }
  async notify(method, params) {
    const req = { jsonrpc: "2.0", method, params };
    await this.send(req, undefined);
  }
}
function formatContent(content) {
  if (content.length === 1 && content[0]?.type === "text") {
    return content[0].text ?? "";
  }
  return content.map((block) => block.type === "text" ? block.text ?? "" : JSON.stringify(block)).join(`
`);
}

class Mcp2 {
  name;
  transport;
  deferred;
  connection;
  constructor({
    name,
    transport,
    deferred
  }) {
    this.name = name;
    this.transport = transport;
    this.deferred = deferred ?? true;
  }
  async connect() {
    const connection = this.transport.type === "stdio" ? new StdioTransport(this.transport) : new HttpTransport(this.transport);
    this.connection = connection;
    await connection.start();
    await connection.request("initialize", {
      protocolVersion: PROTOCOL_VERSION,
      capabilities: {},
      clientInfo: { name: "drone", version: "0.1.0" }
    });
    await connection.notify("notifications/initialized");
    const result = await connection.request("tools/list");
    return result.tools.map((remote) => this.wrap(remote));
  }
  async disconnect() {
    if (!this.connection)
      return;
    const connection = this.connection;
    this.connection = undefined;
    await connection.stop();
  }
  wrap(remote) {
    return new Tool({
      name: `mcp__${this.name}__${remote.name}`,
      description: remote.description ?? `${this.name}.${remote.name}`,
      jsonSchema: remote.inputSchema,
      deferred: this.deferred,
      execute: async (input) => {
        if (!this.connection) {
          throw new Error(`MCP "${this.name}" is not connected.`);
        }
        const result = await this.connection.request("tools/call", {
          name: remote.name,
          arguments: input
        });
        const text = formatContent(result.content);
        if (result.isError)
          throw new Error(text);
        return text;
      }
    });
  }
}

// src/mcp/clients/linear.ts
var LINEAR_MCP_URL = "https://mcp.linear.app/mcp";

class Mcp3 extends Mcp2 {
  constructor(opts) {
    super({
      name: opts.name ?? "linear",
      transport: {
        type: "http",
        url: LINEAR_MCP_URL,
        auth: new BearerAuth(opts.apiKey)
      }
    });
  }
}
var linear_default = Mcp3;

// src/mcp/clients/tenderly.ts
var TENDERLY_MCP_URL = "https://mcp.tenderly.co/mcp";

class Mcp4 extends Mcp2 {
  constructor(opts) {
    const auth = new OAuthAuth({
      serverUrl: TENDERLY_MCP_URL,
      storageKey: "tenderly",
      storage: opts?.storage,
      redirectPort: opts?.redirectPort
    });
    super({
      name: opts?.name ?? "tenderly",
      transport: {
        type: "http",
        url: TENDERLY_MCP_URL,
        auth
      }
    });
  }
}
var tenderly_default = Mcp4;
export {
  tenderly_default as Tenderly,
  linear_default as Linear,
  grafana_default as Grafana
};
