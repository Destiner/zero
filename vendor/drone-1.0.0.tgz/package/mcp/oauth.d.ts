interface AuthorizationServerMetadata {
    authorization_endpoint: string;
    token_endpoint: string;
    registration_endpoint?: string;
    scopes_supported?: string[];
    code_challenge_methods_supported?: string[];
}
interface TokenResponse {
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
    token_type?: string;
    scope?: string;
}
declare function generatePkce(): Promise<{
    verifier: string;
    challenge: string;
}>;
declare function generateState(): string;
declare function discover(serverUrl: string): Promise<AuthorizationServerMetadata>;
declare function registerClient(registrationEndpoint: string, redirectUri: string): Promise<string>;
declare function openBrowser(url: string): void;
declare function captureAuthorizationCode(port: number, expectedState: string, timeoutMs: number): Promise<string>;
declare function exchangeCode(opts: {
    tokenEndpoint: string;
    code: string;
    clientId: string;
    redirectUri: string;
    verifier: string;
}): Promise<TokenResponse>;
declare function refreshTokens(opts: {
    tokenEndpoint: string;
    refreshToken: string;
    clientId: string;
}): Promise<TokenResponse>;
export { captureAuthorizationCode, discover, exchangeCode, generatePkce, generateState, openBrowser, refreshTokens, registerClient, type AuthorizationServerMetadata, type TokenResponse, };
