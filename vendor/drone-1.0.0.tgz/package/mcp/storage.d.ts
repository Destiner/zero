type TokenSet = {
    accessToken: string;
    refreshToken?: string;
    expiresAt?: number;
    clientId?: string;
    redirectUri?: string;
};
interface OAuthStorage {
    load(key: string): Promise<TokenSet | null>;
    save(key: string, tokens: TokenSet): Promise<void>;
    clear(key: string): Promise<void>;
}
declare class FileStorage implements OAuthStorage {
    private path;
    private cache?;
    constructor(path?: string);
    private read;
    private write;
    load(key: string): Promise<TokenSet | null>;
    save(key: string, tokens: TokenSet): Promise<void>;
    clear(key: string): Promise<void>;
}
declare class MemoryStorage implements OAuthStorage {
    private data;
    load(key: string): Promise<TokenSet | null>;
    save(key: string, tokens: TokenSet): Promise<void>;
    clear(key: string): Promise<void>;
}
export { FileStorage, MemoryStorage, type OAuthStorage, type TokenSet };
