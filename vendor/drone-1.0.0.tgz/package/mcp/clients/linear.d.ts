import { Mcp as McpBase } from '../core';
type Options = {
    apiKey: string;
    name?: string;
};
declare class Mcp extends McpBase {
    constructor(opts: Options);
}
export default Mcp;
