import { Tool, type McpClient } from '../../core';
type Options = {
    url: string;
    serviceAccountToken: string;
    name?: string;
    deferred?: boolean;
};
declare class Mcp implements McpClient {
    private baseUrl;
    private auth;
    private nameSpace;
    private deferred;
    constructor(opts: Options);
    connect(): Promise<Tool[]>;
    disconnect(): Promise<void>;
}
export default Mcp;
