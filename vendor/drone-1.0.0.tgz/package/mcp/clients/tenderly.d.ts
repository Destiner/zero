import { Mcp as McpBase } from '../core';
import type { OAuthStorage } from '../storage';
type Options = {
    name?: string;
    storage?: OAuthStorage;
    redirectPort?: number;
};
declare class Mcp extends McpBase {
    constructor(opts?: Options);
}
export default Mcp;
