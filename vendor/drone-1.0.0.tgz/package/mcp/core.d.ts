import { Tool, type McpClient } from '../core';
import type { AuthProvider } from './auth';
type StdioTransportConfig = {
    type: 'stdio';
    command: string;
    args?: string[];
    env?: Record<string, string>;
};
type HttpTransportConfig = {
    type: 'http';
    url: string;
    headers?: Record<string, string>;
    auth?: AuthProvider;
};
type McpTransportConfig = StdioTransportConfig | HttpTransportConfig;
declare class Mcp implements McpClient {
    name: string;
    transport: McpTransportConfig;
    deferred: boolean;
    private connection?;
    constructor({ name, transport, deferred, }: {
        name: string;
        transport: McpTransportConfig;
        deferred?: boolean;
    });
    connect(): Promise<Tool[]>;
    disconnect(): Promise<void>;
    private wrap;
}
export { Mcp, type McpTransportConfig, type StdioTransportConfig, type HttpTransportConfig, };
