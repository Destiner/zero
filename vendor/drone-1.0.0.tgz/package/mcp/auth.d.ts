import { type OAuthStorage } from './storage';
interface AuthProvider {
    getHeader(): Promise<string>;
    onUnauthorized?(): Promise<void>;
}
declare class BearerAuth implements AuthProvider {
    private token;
    constructor(token: string);
    getHeader(): Promise<string>;
}
type OAuthAuthOptions = {
    serverUrl: string;
    storageKey: string;
    storage?: OAuthStorage;
    redirectPort?: number;
    scopes?: string[];
    flowTimeoutMs?: number;
};
declare class OAuthAuth implements AuthProvider {
    private serverUrl;
    private storage;
    private storageKey;
    private redirectPort;
    private scopes?;
    private flowTimeoutMs;
    private tokens?;
    private loaded;
    private metadata?;
    private inFlight?;
    constructor(opts: OAuthAuthOptions);
    getHeader(): Promise<string>;
    onUnauthorized(): Promise<void>;
    private ensureTokens;
    private isExpired;
    private getMetadata;
    private authorize;
    private refresh;
    private toTokenSet;
}
export { BearerAuth, OAuthAuth, type AuthProvider, type OAuthAuthOptions };
