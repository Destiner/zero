// @bun
// src/core/agent.ts
import { z as z2 } from "zod";

// src/core/session.ts
class Turn {
  queue = [];
  waiters = [];
  ended = false;
  iterated = false;
  resultPromise;
  abortController = new AbortController;
  constructor(runner) {
    this.resultPromise = runner({
      emit: (event) => this.emit(event),
      signal: this.abortController.signal
    }).then((messages) => {
      this.close();
      return messages;
    }, (error) => {
      this.close();
      throw error;
    });
    this.resultPromise.catch(() => {});
  }
  emit(event) {
    const waiter = this.waiters.shift();
    if (waiter) {
      waiter({ value: event, done: false });
    } else {
      this.queue.push(event);
    }
  }
  close() {
    this.ended = true;
    while (this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      waiter?.({ value: undefined, done: true });
    }
  }
  abort(reason) {
    this.abortController.abort(reason);
  }
  [Symbol.asyncIterator]() {
    if (this.iterated) {
      throw new Error("Turn can only be iterated once.");
    }
    this.iterated = true;
    return {
      next: () => {
        if (this.queue.length > 0) {
          const value = this.queue.shift();
          return Promise.resolve({ value, done: false });
        }
        if (this.ended) {
          return Promise.resolve({
            value: undefined,
            done: true
          });
        }
        return new Promise((resolve) => this.waiters.push(resolve));
      },
      return: async () => {
        this.abort("iteration ended");
        await this.resultPromise.catch(() => {});
        return {
          value: undefined,
          done: true
        };
      }
    };
  }
  then(onfulfilled, onrejected) {
    return this.resultPromise.then(onfulfilled, onrejected);
  }
}

class Session {
  internals;
  state;
  constructor(internals, state) {
    this.internals = internals;
    this.state = state;
  }
  get messages() {
    return this.state.messages;
  }
  send(prompt) {
    return this.internals.send(prompt);
  }
  async close() {
    await this.internals.close();
  }
  async[Symbol.asyncDispose]() {
    await this.close();
  }
}

// src/core/tool.ts
import { z } from "zod";

class Tool {
  name;
  description;
  inputSchema;
  jsonSchema;
  execute;
  deferred;
  constructor(init) {
    this.name = init.name;
    this.description = init.description;
    this.deferred = init.deferred ?? false;
    if ("inputSchema" in init) {
      this.inputSchema = init.inputSchema;
      this.execute = init.execute;
    } else {
      this.jsonSchema = init.jsonSchema;
      this.execute = init.execute;
    }
  }
  toJsonSchema() {
    if (this.jsonSchema !== undefined)
      return this.jsonSchema;
    if (this.inputSchema === undefined) {
      throw new Error(`Tool "${this.name}" has neither inputSchema nor jsonSchema.`);
    }
    return z.toJSONSchema(this.inputSchema);
  }
  parse(input) {
    if (this.inputSchema)
      return this.inputSchema.parse(input);
    return input;
  }
}
function createRegistry(tools) {
  const byName = new Map(tools.map((tool) => [tool.name, tool]));
  const loadedNames = new Set(tools.filter((tool) => !tool.deferred).map((tool) => tool.name));
  return {
    loaded: () => tools.filter((tool) => loadedNames.has(tool.name)),
    deferred: () => tools.filter((tool) => tool.deferred && !loadedNames.has(tool.name)),
    load: (names) => {
      const loaded = [];
      const missing = [];
      for (const name of names) {
        const tool = byName.get(name);
        if (!tool) {
          missing.push(name);
          continue;
        }
        loadedNames.add(name);
        loaded.push(tool);
      }
      return { loaded, missing };
    }
  };
}

// src/core/agent.ts
class Agent {
  model;
  prompt;
  tools;
  skills;
  mcp;
  cwd;
  registrations = [];
  unsubs = [];
  constructor({
    model,
    prompt,
    tools,
    skills,
    mcp,
    cwd
  }) {
    this.model = model;
    this.prompt = prompt;
    this.tools = tools;
    this.skills = skills;
    this.mcp = mcp ?? [];
    this.cwd = cwd;
  }
  on(trigger, handler) {
    this.registrations.push({ trigger, handler });
  }
  async start() {
    for (const { trigger, handler } of this.registrations) {
      const unsub = await trigger.start((event) => {
        Promise.resolve().then(() => handler(event)).catch((error) => {
          const message = error instanceof Error ? error.message : String(error);
          console.error(`[drone] trigger "${trigger.name}" handler failed: ${message}`);
        });
      });
      this.unsubs.push(unsub);
    }
  }
  async stop() {
    const unsubs = this.unsubs;
    this.unsubs = [];
    await Promise.all(unsubs.map((u) => u()));
  }
  buildSystem(allTools) {
    let system = this.prompt;
    if (this.skills.length > 0) {
      const skillsList = this.skills.map((skill) => `- ${skill.name}: ${skill.description}`).join(`
`);
      system = `${system}

# Skills
The following skills are available. When a task matches one, call the \`Skill\` tool with that skill's name to load its full content before proceeding.

${skillsList}`;
    }
    const deferred = allTools.filter((tool) => tool.deferred);
    if (deferred.length > 0) {
      const list = deferred.map((tool) => `- ${tool.name}`).join(`
`);
      system = `${system}

# Deferred tools
These tools are available but their schemas are not loaded. Use ToolSearch to load them before calling.
${list}`;
    }
    return system;
  }
  buildSkillTool() {
    const byName = new Map(this.skills.map((skill) => [skill.name, skill]));
    return new Tool({
      name: "Skill",
      description: 'Load the full content of a skill listed under "# Skills" in the system prompt. Call this when you decide a listed skill applies to the current task; the returned content extends your instructions for the rest of the session.',
      inputSchema: z2.object({
        skill: z2.string().describe("Name of the skill to load (must match a listed skill).")
      }),
      execute: ({ skill }) => {
        const found = byName.get(skill);
        if (!found) {
          const available = [...byName.keys()].join(", ");
          throw new Error(`Skill "${skill}" not found. Available: ${available}`);
        }
        return `<skill name="${found.name}">
${found.content}
</skill>`;
      }
    });
  }
  session(init) {
    const initialMessages = init?.messages ? [...init.messages] : [];
    const sessionCwd = init?.cwd ?? this.cwd ?? process.cwd();
    const state = {
      messages: initialMessages,
      store: new Map
    };
    let activeTurn = null;
    let mcpConnected = false;
    let allTools = null;
    let registry = null;
    let ctx = null;
    const ensureReady = async () => {
      if (!allTools || !registry || !ctx) {
        const mcpToolGroups = await Promise.all(this.mcp.map((mcp) => mcp.connect()));
        mcpConnected = true;
        allTools = [
          ...this.tools,
          ...mcpToolGroups.flat(),
          ...this.skills.length > 0 ? [this.buildSkillTool()] : []
        ];
        registry = createRegistry(allTools);
        ctx = {
          complete: async (p) => {
            const response = await this.model.createMessage({
              messages: [{ role: "user", content: p }]
            });
            return response.content.filter((block) => block.type === "text").map((block) => block.text).join(`
`);
          },
          searchWeb: (query, opts) => this.model.searchWeb(query, opts),
          session: state,
          tools: registry,
          cwd: sessionCwd
        };
        if (state.messages.length === 0 || state.messages[0]?.role !== "system") {
          state.messages.unshift({
            role: "system",
            content: this.buildSystem(allTools)
          });
        }
      }
      return { tools: allTools, registry, ctx };
    };
    const internals = {
      send: (prompt) => {
        if (activeTurn !== null) {
          throw new Error("Session.send() called while another turn is in flight.");
        }
        const turn = new Turn(async (turnCtx) => {
          try {
            const ready = await ensureReady();
            state.messages.push(toUserMessage(prompt));
            await runAgentLoop({
              model: this.model,
              state,
              registry: ready.registry,
              ctx: ready.ctx,
              emit: turnCtx.emit,
              signal: turnCtx.signal
            });
            return [...state.messages];
          } finally {
            activeTurn = null;
          }
        });
        activeTurn = turn;
        return turn;
      },
      close: async () => {
        const pending = activeTurn;
        if (pending) {
          pending.abort("session closed");
          await Promise.resolve(pending).catch(() => {});
        }
        if (mcpConnected) {
          await Promise.all(this.mcp.map((mcp) => mcp.disconnect()));
          mcpConnected = false;
        }
      }
    };
    return new Session(internals, state);
  }
}
function toUserMessage(prompt) {
  if (typeof prompt === "string")
    return { role: "user", content: prompt };
  return { role: "user", content: prompt };
}
async function runAgentLoop({
  model,
  state,
  registry,
  ctx,
  emit,
  signal
}) {
  while (true) {
    if (signal.aborted)
      break;
    const active = registry.loaded();
    const toolByName = new Map(active.map((tool) => [tool.name, tool]));
    emit({ type: "message-start" });
    const assistantContent = [];
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    try {
      for await (const event of model.streamMessage({
        messages: state.messages,
        tools: active,
        signal
      })) {
        switch (event.type) {
          case "text-delta":
            emit({ type: "text-delta", text: event.text });
            break;
          case "text-end":
            assistantContent.push({ type: "text", text: event.text });
            emit({ type: "text", text: event.text });
            break;
          case "thinking-delta":
            emit({ type: "thinking-delta", text: event.text });
            break;
          case "thinking-end":
            assistantContent.push({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {},
              ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
            });
            emit({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {}
            });
            break;
          case "tool-call":
            assistantContent.push({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            emit({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            break;
          case "message-end":
            stopReason = event.stopReason;
            usage = event.usage;
            break;
          default:
            break;
        }
      }
    } catch (error) {
      if (signal.aborted) {
        state.messages.push({ role: "assistant", content: assistantContent });
        break;
      }
      const err = error instanceof Error ? error : new Error(String(error));
      emit({ type: "error", error: err });
      throw err;
    }
    state.messages.push({ role: "assistant", content: assistantContent });
    emit({ type: "message-end", usage });
    if (stopReason !== "tool_use") {
      emit({ type: "turn-end" });
      break;
    }
    const toolCalls = assistantContent.filter((block) => block.type === "tool-call");
    const results = [];
    for (const call of toolCalls) {
      if (signal.aborted)
        break;
      const tool = toolByName.get(call.toolName);
      const result = await runTool(tool, call, ctx);
      results.push(result);
      emit({
        type: "tool-result",
        toolCallId: result.toolCallId,
        toolName: result.toolName,
        output: result.output,
        isError: typeof result.output === "string" ? result.output.startsWith("Error:") : false
      });
    }
    state.messages.push({ role: "tool", content: results });
    if (signal.aborted)
      break;
  }
}
async function runTool(tool, call, ctx) {
  if (!tool) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: tool "${call.toolName}" not found`
    };
  }
  try {
    const parsed = tool.parse(call.input);
    const output = await tool.execute(parsed, ctx);
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output
    };
  } catch (error) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}

// src/core/model.ts
class Model {
  async createMessage(params) {
    const content = [];
    let id = "";
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    for await (const event of this.streamMessage(params)) {
      switch (event.type) {
        case "text-end":
          content.push({ type: "text", text: event.text });
          break;
        case "thinking-end":
          content.push({
            type: "thinking",
            text: event.text,
            ...event.signature !== undefined ? { signature: event.signature } : {},
            ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
          });
          break;
        case "tool-call":
          content.push({
            type: "tool-call",
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            input: event.input
          });
          break;
        case "message-end":
          id = event.id;
          stopReason = event.stopReason;
          usage = event.usage;
          break;
        default:
          break;
      }
    }
    return { id, content, stopReason, usage };
  }
}

// src/core/skill.ts
class Skill {
  name;
  description;
  content;
  constructor({
    name,
    description,
    content
  }) {
    this.name = name;
    this.description = description;
    this.content = content;
  }
}
export {
  Turn,
  Tool,
  Skill,
  Session,
  Model,
  Agent
};
