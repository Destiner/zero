export declare const env: {
    readonly anthropicApiKey: string | undefined;
    readonly geminiApiKey: string | undefined;
    readonly moonshotApiKey: string | undefined;
    readonly openaiApiKey: string | undefined;
    readonly openaiCodexAuthFile: string | undefined;
    readonly codexHome: string | undefined;
};
