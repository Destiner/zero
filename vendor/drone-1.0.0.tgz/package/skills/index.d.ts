import { Skill } from '../core';
declare const prReview: Skill;
declare const docsUpdate: Skill;
declare const publicDocs: Skill;
declare const developerExperience: Skill;
declare const codeSimplifier: Skill;
export { prReview, docsUpdate, publicDocs, developerExperience, codeSimplifier, };
