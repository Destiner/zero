// @bun
// src/core/agent.ts
import { z as z2 } from "zod";

// src/core/session.ts
class Turn {
  queue = [];
  waiters = [];
  ended = false;
  iterated = false;
  resultPromise;
  abortController = new AbortController;
  constructor(runner) {
    this.resultPromise = runner({
      emit: (event) => this.emit(event),
      signal: this.abortController.signal
    }).then((messages) => {
      this.close();
      return messages;
    }, (error) => {
      this.close();
      throw error;
    });
    this.resultPromise.catch(() => {});
  }
  emit(event) {
    const waiter = this.waiters.shift();
    if (waiter) {
      waiter({ value: event, done: false });
    } else {
      this.queue.push(event);
    }
  }
  close() {
    this.ended = true;
    while (this.waiters.length > 0) {
      const waiter = this.waiters.shift();
      waiter?.({ value: undefined, done: true });
    }
  }
  abort(reason) {
    this.abortController.abort(reason);
  }
  [Symbol.asyncIterator]() {
    if (this.iterated) {
      throw new Error("Turn can only be iterated once.");
    }
    this.iterated = true;
    return {
      next: () => {
        if (this.queue.length > 0) {
          const value = this.queue.shift();
          return Promise.resolve({ value, done: false });
        }
        if (this.ended) {
          return Promise.resolve({
            value: undefined,
            done: true
          });
        }
        return new Promise((resolve) => this.waiters.push(resolve));
      },
      return: async () => {
        this.abort("iteration ended");
        await this.resultPromise.catch(() => {});
        return {
          value: undefined,
          done: true
        };
      }
    };
  }
  then(onfulfilled, onrejected) {
    return this.resultPromise.then(onfulfilled, onrejected);
  }
}

class Session {
  internals;
  state;
  constructor(internals, state) {
    this.internals = internals;
    this.state = state;
  }
  get messages() {
    return this.state.messages;
  }
  send(prompt) {
    return this.internals.send(prompt);
  }
  async close() {
    await this.internals.close();
  }
  async[Symbol.asyncDispose]() {
    await this.close();
  }
}

// src/core/tool.ts
import { z } from "zod";

class Tool {
  name;
  description;
  inputSchema;
  jsonSchema;
  execute;
  deferred;
  constructor(init) {
    this.name = init.name;
    this.description = init.description;
    this.deferred = init.deferred ?? false;
    if ("inputSchema" in init) {
      this.inputSchema = init.inputSchema;
      this.execute = init.execute;
    } else {
      this.jsonSchema = init.jsonSchema;
      this.execute = init.execute;
    }
  }
  toJsonSchema() {
    if (this.jsonSchema !== undefined)
      return this.jsonSchema;
    if (this.inputSchema === undefined) {
      throw new Error(`Tool "${this.name}" has neither inputSchema nor jsonSchema.`);
    }
    return z.toJSONSchema(this.inputSchema);
  }
  parse(input) {
    if (this.inputSchema)
      return this.inputSchema.parse(input);
    return input;
  }
}
function createRegistry(tools) {
  const byName = new Map(tools.map((tool) => [tool.name, tool]));
  const loadedNames = new Set(tools.filter((tool) => !tool.deferred).map((tool) => tool.name));
  return {
    loaded: () => tools.filter((tool) => loadedNames.has(tool.name)),
    deferred: () => tools.filter((tool) => tool.deferred && !loadedNames.has(tool.name)),
    load: (names) => {
      const loaded = [];
      const missing = [];
      for (const name of names) {
        const tool = byName.get(name);
        if (!tool) {
          missing.push(name);
          continue;
        }
        loadedNames.add(name);
        loaded.push(tool);
      }
      return { loaded, missing };
    }
  };
}

// src/core/agent.ts
class Agent {
  model;
  prompt;
  tools;
  skills;
  mcp;
  cwd;
  registrations = [];
  unsubs = [];
  constructor({
    model,
    prompt,
    tools,
    skills,
    mcp,
    cwd
  }) {
    this.model = model;
    this.prompt = prompt;
    this.tools = tools;
    this.skills = skills;
    this.mcp = mcp ?? [];
    this.cwd = cwd;
  }
  on(trigger, handler) {
    this.registrations.push({ trigger, handler });
  }
  async start() {
    for (const { trigger, handler } of this.registrations) {
      const unsub = await trigger.start((event) => {
        Promise.resolve().then(() => handler(event)).catch((error) => {
          const message = error instanceof Error ? error.message : String(error);
          console.error(`[drone] trigger "${trigger.name}" handler failed: ${message}`);
        });
      });
      this.unsubs.push(unsub);
    }
  }
  async stop() {
    const unsubs = this.unsubs;
    this.unsubs = [];
    await Promise.all(unsubs.map((u) => u()));
  }
  buildSystem(allTools) {
    let system = this.prompt;
    if (this.skills.length > 0) {
      const skillsList = this.skills.map((skill) => `- ${skill.name}: ${skill.description}`).join(`
`);
      system = `${system}

# Skills
The following skills are available. When a task matches one, call the \`Skill\` tool with that skill's name to load its full content before proceeding.

${skillsList}`;
    }
    const deferred = allTools.filter((tool) => tool.deferred);
    if (deferred.length > 0) {
      const list = deferred.map((tool) => `- ${tool.name}`).join(`
`);
      system = `${system}

# Deferred tools
These tools are available but their schemas are not loaded. Use ToolSearch to load them before calling.
${list}`;
    }
    return system;
  }
  buildSkillTool() {
    const byName = new Map(this.skills.map((skill) => [skill.name, skill]));
    return new Tool({
      name: "Skill",
      description: 'Load the full content of a skill listed under "# Skills" in the system prompt. Call this when you decide a listed skill applies to the current task; the returned content extends your instructions for the rest of the session.',
      inputSchema: z2.object({
        skill: z2.string().describe("Name of the skill to load (must match a listed skill).")
      }),
      execute: ({ skill }) => {
        const found = byName.get(skill);
        if (!found) {
          const available = [...byName.keys()].join(", ");
          throw new Error(`Skill "${skill}" not found. Available: ${available}`);
        }
        return `<skill name="${found.name}">
${found.content}
</skill>`;
      }
    });
  }
  session(init) {
    const initialMessages = init?.messages ? [...init.messages] : [];
    const sessionCwd = init?.cwd ?? this.cwd ?? process.cwd();
    const state = {
      messages: initialMessages,
      store: new Map
    };
    let activeTurn = null;
    let mcpConnected = false;
    let allTools = null;
    let registry = null;
    let ctx = null;
    const ensureReady = async () => {
      if (!allTools || !registry || !ctx) {
        const mcpToolGroups = await Promise.all(this.mcp.map((mcp) => mcp.connect()));
        mcpConnected = true;
        allTools = [
          ...this.tools,
          ...mcpToolGroups.flat(),
          ...this.skills.length > 0 ? [this.buildSkillTool()] : []
        ];
        registry = createRegistry(allTools);
        ctx = {
          complete: async (p) => {
            const response = await this.model.createMessage({
              messages: [{ role: "user", content: p }]
            });
            return response.content.filter((block) => block.type === "text").map((block) => block.text).join(`
`);
          },
          searchWeb: (query, opts) => this.model.searchWeb(query, opts),
          session: state,
          tools: registry,
          cwd: sessionCwd
        };
        if (state.messages.length === 0 || state.messages[0]?.role !== "system") {
          state.messages.unshift({
            role: "system",
            content: this.buildSystem(allTools)
          });
        }
      }
      return { tools: allTools, registry, ctx };
    };
    const internals = {
      send: (prompt) => {
        if (activeTurn !== null) {
          throw new Error("Session.send() called while another turn is in flight.");
        }
        const turn = new Turn(async (turnCtx) => {
          try {
            const ready = await ensureReady();
            state.messages.push(toUserMessage(prompt));
            await runAgentLoop({
              model: this.model,
              state,
              registry: ready.registry,
              ctx: ready.ctx,
              emit: turnCtx.emit,
              signal: turnCtx.signal
            });
            return [...state.messages];
          } finally {
            activeTurn = null;
          }
        });
        activeTurn = turn;
        return turn;
      },
      close: async () => {
        const pending = activeTurn;
        if (pending) {
          pending.abort("session closed");
          await Promise.resolve(pending).catch(() => {});
        }
        if (mcpConnected) {
          await Promise.all(this.mcp.map((mcp) => mcp.disconnect()));
          mcpConnected = false;
        }
      }
    };
    return new Session(internals, state);
  }
}
function toUserMessage(prompt) {
  if (typeof prompt === "string")
    return { role: "user", content: prompt };
  return { role: "user", content: prompt };
}
async function runAgentLoop({
  model,
  state,
  registry,
  ctx,
  emit,
  signal
}) {
  while (true) {
    if (signal.aborted)
      break;
    const active = registry.loaded();
    const toolByName = new Map(active.map((tool) => [tool.name, tool]));
    emit({ type: "message-start" });
    const assistantContent = [];
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    try {
      for await (const event of model.streamMessage({
        messages: state.messages,
        tools: active,
        signal
      })) {
        switch (event.type) {
          case "text-delta":
            emit({ type: "text-delta", text: event.text });
            break;
          case "text-end":
            assistantContent.push({ type: "text", text: event.text });
            emit({ type: "text", text: event.text });
            break;
          case "thinking-delta":
            emit({ type: "thinking-delta", text: event.text });
            break;
          case "thinking-end":
            assistantContent.push({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {},
              ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
            });
            emit({
              type: "thinking",
              text: event.text,
              ...event.signature !== undefined ? { signature: event.signature } : {}
            });
            break;
          case "tool-call":
            assistantContent.push({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            emit({
              type: "tool-call",
              toolCallId: event.toolCallId,
              toolName: event.toolName,
              input: event.input
            });
            break;
          case "message-end":
            stopReason = event.stopReason;
            usage = event.usage;
            break;
          default:
            break;
        }
      }
    } catch (error) {
      if (signal.aborted) {
        state.messages.push({ role: "assistant", content: assistantContent });
        break;
      }
      const err = error instanceof Error ? error : new Error(String(error));
      emit({ type: "error", error: err });
      throw err;
    }
    state.messages.push({ role: "assistant", content: assistantContent });
    emit({ type: "message-end", usage });
    if (stopReason !== "tool_use") {
      emit({ type: "turn-end" });
      break;
    }
    const toolCalls = assistantContent.filter((block) => block.type === "tool-call");
    const results = [];
    for (const call of toolCalls) {
      if (signal.aborted)
        break;
      const tool = toolByName.get(call.toolName);
      const result = await runTool(tool, call, ctx);
      results.push(result);
      emit({
        type: "tool-result",
        toolCallId: result.toolCallId,
        toolName: result.toolName,
        output: result.output,
        isError: typeof result.output === "string" ? result.output.startsWith("Error:") : false
      });
    }
    state.messages.push({ role: "tool", content: results });
    if (signal.aborted)
      break;
  }
}
async function runTool(tool, call, ctx) {
  if (!tool) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: tool "${call.toolName}" not found`
    };
  }
  try {
    const parsed = tool.parse(call.input);
    const output = await tool.execute(parsed, ctx);
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output
    };
  } catch (error) {
    return {
      type: "tool-result",
      toolCallId: call.toolCallId,
      toolName: call.toolName,
      output: `Error: ${error instanceof Error ? error.message : String(error)}`
    };
  }
}

// src/core/model.ts
class Model {
  async createMessage(params) {
    const content = [];
    let id = "";
    let stopReason = "end_turn";
    let usage = { inputTokens: 0, outputTokens: 0 };
    for await (const event of this.streamMessage(params)) {
      switch (event.type) {
        case "text-end":
          content.push({ type: "text", text: event.text });
          break;
        case "thinking-end":
          content.push({
            type: "thinking",
            text: event.text,
            ...event.signature !== undefined ? { signature: event.signature } : {},
            ...event.redactedData !== undefined ? { redactedData: event.redactedData } : {}
          });
          break;
        case "tool-call":
          content.push({
            type: "tool-call",
            toolCallId: event.toolCallId,
            toolName: event.toolName,
            input: event.input
          });
          break;
        case "message-end":
          id = event.id;
          stopReason = event.stopReason;
          usage = event.usage;
          break;
        default:
          break;
      }
    }
    return { id, content, stopReason, usage };
  }
}

// src/core/skill.ts
class Skill {
  name;
  description;
  content;
  constructor({
    name,
    description,
    content
  }) {
    this.name = name;
    this.description = description;
    this.content = content;
  }
}

// src/core/stream.ts
async function* readSse(response) {
  if (!response.body) {
    throw new Error("Response body is empty; cannot stream.");
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder;
  let buffer = "";
  function* drain() {
    let sepIdx = findEventBoundary(buffer);
    while (sepIdx !== -1) {
      const rawEvent = buffer.slice(0, sepIdx.start);
      buffer = buffer.slice(sepIdx.end);
      const payload = extractDataPayload(rawEvent);
      if (payload !== undefined) {
        yield parsePayload(payload);
      }
      sepIdx = findEventBoundary(buffer);
    }
  }
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done)
        break;
      buffer += decoder.decode(value, { stream: true });
      yield* drain();
    }
    buffer += decoder.decode();
    yield* drain();
    if (buffer.trim().length > 0) {
      const payload = extractDataPayload(buffer);
      if (payload !== undefined) {
        yield parsePayload(payload);
      } else {
        throw new Error(`SSE stream ended with unterminated buffer: ${buffer.slice(0, 200)}`);
      }
    }
  } finally {
    reader.releaseLock();
  }
}
function parsePayload(payload) {
  try {
    return JSON.parse(payload);
  } catch (error) {
    throw new Error(`Malformed SSE event payload: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
  }
}
function findEventBoundary(buffer) {
  const candidates = [`\r
\r
`, `

`, "\r\r"];
  let best = -1;
  let bestLen = 0;
  for (const sep of candidates) {
    const idx = buffer.indexOf(sep);
    if (idx === -1)
      continue;
    if (best === -1 || idx < best) {
      best = idx;
      bestLen = sep.length;
    }
  }
  if (best === -1)
    return -1;
  return { start: best, end: best + bestLen };
}
function extractDataPayload(rawEvent) {
  const lines = rawEvent.split(/\r?\n/);
  const dataLines = [];
  for (const line of lines) {
    if (!line.startsWith("data:"))
      continue;
    dataLines.push(line.slice("data:".length).replace(/^ /, ""));
  }
  if (dataLines.length === 0)
    return;
  const joined = dataLines.join(`
`);
  if (joined === "[DONE]")
    return;
  return joined;
}

// src/env.ts
function read(name) {
  const value = process.env[name];
  return value && value.length > 0 ? value : undefined;
}
var env = {
  get anthropicApiKey() {
    return read("ANTHROPIC_API_KEY");
  },
  get geminiApiKey() {
    return read("GEMINI_API_KEY");
  },
  get moonshotApiKey() {
    return read("MOONSHOT_API_KEY");
  },
  get openaiApiKey() {
    return read("OPENAI_API_KEY");
  },
  get openaiCodexAuthFile() {
    return read("DRONE_OPENAI_CODEX_AUTH_FILE");
  },
  get codexHome() {
    return read("CODEX_HOME");
  }
};

// src/models/anthropic.ts
var ANTHROPIC_MODELS = [
  "claude-opus-4-7",
  "claude-opus-4-6",
  "claude-sonnet-4-6",
  "claude-sonnet-4-5",
  "claude-haiku-4-5"
];
var ANTHROPIC_BUDGETS = {
  minimal: 1024,
  low: 4000,
  medium: 1e4,
  high: 31999,
  xhigh: 50000
};
var ANTHROPIC_OUTPUT_BUFFER = 4096;
var ADAPTIVE_THINKING_MODELS = new Set(["claude-opus-4-7"]);
var ADAPTIVE_EFFORTS = {
  minimal: "minimal",
  low: "low",
  medium: "medium",
  high: "high",
  xhigh: "high"
};
function serializeToolOutput(output) {
  if (output === undefined || output === null)
    return "";
  if (typeof output === "string")
    return output;
  return JSON.stringify(output);
}
function toWire(messages) {
  let system;
  const wireMessages = [];
  for (const msg of messages) {
    if (msg.role === "system") {
      system = msg.content;
      continue;
    }
    if (msg.role === "user") {
      const content = typeof msg.content === "string" ? [{ type: "text", text: msg.content }] : msg.content.map((part) => ({ type: "text", text: part.text }));
      wireMessages.push({ role: "user", content });
      continue;
    }
    if (msg.role === "assistant") {
      const content = [];
      for (const part of msg.content) {
        if (part.type === "text") {
          content.push({ type: "text", text: part.text });
          continue;
        }
        if (part.type === "thinking") {
          if (part.redactedData !== undefined) {
            content.push({
              type: "redacted_thinking",
              data: part.redactedData
            });
          } else if (part.signature !== undefined && part.signature !== "") {
            content.push({
              type: "thinking",
              thinking: part.text,
              signature: part.signature
            });
          }
          continue;
        }
        content.push({
          type: "tool_use",
          id: part.toolCallId,
          name: part.toolName,
          input: part.input
        });
      }
      wireMessages.push({ role: "assistant", content });
      continue;
    }
    wireMessages.push({
      role: "user",
      content: msg.content.map((part) => ({
        type: "tool_result",
        tool_use_id: part.toolCallId,
        content: serializeToolOutput(part.output)
      }))
    });
  }
  return { system, wireMessages };
}

class AnthropicModel extends Model {
  modelName;
  apiKey;
  thinking;
  constructor(modelName, options) {
    super();
    this.modelName = modelName;
    const key = options?.apiKey ?? env.anthropicApiKey;
    if (!key) {
      throw new Error("No Anthropic API key found. Set ANTHROPIC_API_KEY or pass apiKey.");
    }
    this.apiKey = key;
    this.thinking = options?.thinking ?? "off";
  }
  async* streamMessage(params) {
    const { messages, tools, maxTokens = 8192, signal } = params;
    const { system, wireMessages } = toWire(messages);
    const wireTools = tools?.map((tool) => ({
      name: tool.name,
      description: tool.description,
      input_schema: tool.toJsonSchema()
    }));
    const useAdaptive = ADAPTIVE_THINKING_MODELS.has(this.modelName);
    const budget = this.thinking === "off" || useAdaptive ? undefined : ANTHROPIC_BUDGETS[this.thinking];
    const effectiveMaxTokens = budget === undefined ? maxTokens : Math.max(maxTokens, budget + ANTHROPIC_OUTPUT_BUFFER);
    const body = {
      model: this.modelName,
      max_tokens: effectiveMaxTokens,
      messages: wireMessages,
      stream: true
    };
    if (system !== undefined)
      body.system = system;
    if (wireTools !== undefined && wireTools.length > 0)
      body.tools = wireTools;
    if (budget !== undefined) {
      body.thinking = { type: "enabled", budget_tokens: budget };
    } else if (useAdaptive && this.thinking !== "off") {
      body.thinking = { type: "adaptive" };
      body.output_config = { effort: ADAPTIVE_EFFORTS[this.thinking] };
    }
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01",
        accept: "text/event-stream"
      },
      body: JSON.stringify(body),
      signal
    });
    if (!response.ok) {
      throw new Error(`Anthropic API error ${response.status}: ${await response.text()}`);
    }
    const blocks = new Map;
    let id = "";
    let stopReason = "end_turn";
    let inputTokens = 0;
    let outputTokens = 0;
    let sawMessageStop = false;
    for await (const raw of readSse(response)) {
      const event = raw;
      if (event.type === "message_start") {
        id = event.message.id;
        if (event.message.usage?.input_tokens !== undefined) {
          inputTokens = event.message.usage.input_tokens;
        }
        if (event.message.usage?.output_tokens !== undefined) {
          outputTokens = event.message.usage.output_tokens;
        }
        continue;
      }
      if (event.type === "content_block_start") {
        const block = event.content_block;
        if (block.type === "text") {
          blocks.set(event.index, { kind: "text", text: block.text ?? "" });
        } else if (block.type === "thinking") {
          blocks.set(event.index, {
            kind: "thinking",
            text: block.thinking ?? ""
          });
        } else if (block.type === "redacted_thinking") {
          blocks.set(event.index, {
            kind: "redacted_thinking",
            text: "",
            redactedData: block.data
          });
        } else if (block.type === "tool_use") {
          blocks.set(event.index, {
            kind: "tool_use",
            text: "",
            toolCallId: block.id,
            toolName: block.name,
            argsBuffer: ""
          });
        }
        continue;
      }
      if (event.type === "content_block_delta") {
        const builder = blocks.get(event.index);
        if (!builder)
          continue;
        const delta = event.delta;
        if (delta.type === "text_delta") {
          builder.text += delta.text;
          yield { type: "text-delta", text: delta.text };
        } else if (delta.type === "thinking_delta") {
          builder.text += delta.thinking;
          yield { type: "thinking-delta", text: delta.thinking };
        } else if (delta.type === "signature_delta") {
          builder.signature = (builder.signature ?? "") + delta.signature;
        } else if (delta.type === "input_json_delta") {
          builder.argsBuffer = (builder.argsBuffer ?? "") + delta.partial_json;
        }
        continue;
      }
      if (event.type === "content_block_stop") {
        const builder = blocks.get(event.index);
        if (!builder)
          continue;
        if (builder.kind === "text") {
          yield { type: "text-end", text: builder.text };
        } else if (builder.kind === "thinking") {
          yield {
            type: "thinking-end",
            text: builder.text,
            ...builder.signature !== undefined ? { signature: builder.signature } : {}
          };
        } else if (builder.kind === "redacted_thinking") {
          yield {
            type: "thinking-end",
            text: "",
            redactedData: builder.redactedData
          };
        } else if (builder.kind === "tool_use") {
          const input = parseToolInput(builder.argsBuffer ?? "");
          yield {
            type: "tool-call",
            toolCallId: builder.toolCallId ?? "",
            toolName: builder.toolName ?? "",
            input
          };
        }
        blocks.delete(event.index);
        continue;
      }
      if (event.type === "message_delta") {
        if (event.delta.stop_reason)
          stopReason = event.delta.stop_reason;
        if (event.usage?.input_tokens !== undefined) {
          inputTokens = event.usage.input_tokens;
        }
        if (event.usage?.output_tokens !== undefined) {
          outputTokens = event.usage.output_tokens;
        }
        continue;
      }
      if (event.type === "message_stop") {
        sawMessageStop = true;
        continue;
      }
      if (event.type === "error") {
        throw new Error(event.error?.message ?? "Anthropic stream returned an error.");
      }
    }
    if (!sawMessageStop) {
      throw new Error("Anthropic stream ended before message_stop; response is truncated.");
    }
    yield {
      type: "message-end",
      id,
      stopReason,
      usage: { inputTokens, outputTokens }
    };
  }
  async searchWeb(query, opts) {
    const tool = {
      type: "web_search_20250305",
      name: "web_search"
    };
    if (opts?.allowedDomains)
      tool.allowed_domains = opts.allowedDomains;
    if (opts?.blockedDomains)
      tool.blocked_domains = opts.blockedDomains;
    if (opts?.maxUses !== undefined)
      tool.max_uses = opts.maxUses;
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": this.apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: this.modelName,
        max_tokens: 1024,
        tools: [tool],
        messages: [{ role: "user", content: `Search the web for: ${query}` }]
      })
    });
    if (!response.ok) {
      throw new Error(`Anthropic web_search failed (${response.status}): ${await response.text()}`);
    }
    const json = await response.json();
    const hits = [];
    for (const block of json.content) {
      if (block.type !== "web_search_tool_result")
        continue;
      const content = block.content;
      if (!Array.isArray(content))
        continue;
      for (const item of content) {
        if (item.type !== "web_search_result")
          continue;
        hits.push({
          title: item.title,
          url: item.url,
          pageAge: item.page_age ?? undefined
        });
      }
    }
    return hits;
  }
}
function parseToolInput(raw) {
  if (!raw)
    return {};
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

// src/models/openai-compatible.ts
function serializeToolOutput2(output) {
  if (output === undefined || output === null)
    return "";
  if (typeof output === "string")
    return output;
  return JSON.stringify(output);
}
function mapFinishReason(reason) {
  switch (reason) {
    case "stop":
      return "end_turn";
    case "tool_calls":
      return "tool_use";
    case "length":
      return "max_tokens";
    case "content_filter":
      return "refusal";
    default:
      return "end_turn";
  }
}
function parseToolArguments(raw) {
  if (!raw)
    return {};
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}

class OpenAICompatibleModel extends Model {
  modelName;
  apiKey;
  baseUrl;
  thinking;
  constructor(modelName, options) {
    super();
    this.modelName = modelName;
    this.apiKey = options.apiKey;
    this.baseUrl = options.baseUrl;
    this.thinking = options.thinking ?? "off";
  }
  async* streamMessage(params) {
    const { messages, tools, maxTokens = 8192, signal } = params;
    const wireMessages = this.serializeMessages(messages);
    const wireTools = tools?.map((tool) => ({
      type: "function",
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.toJsonSchema()
      }
    }));
    const body = {
      model: this.modelName,
      messages: wireMessages,
      max_completion_tokens: maxTokens,
      stream: true,
      stream_options: { include_usage: true }
    };
    if (wireTools !== undefined && wireTools.length > 0)
      body.tools = wireTools;
    this.applyThinking(body);
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${this.apiKey}`,
        accept: "text/event-stream"
      },
      body: JSON.stringify(body),
      signal
    });
    if (!response.ok) {
      throw new Error(`Chat completions error ${response.status}: ${await response.text()}`);
    }
    let id = "";
    let stopReason = "end_turn";
    let inputTokens = 0;
    let outputTokens = 0;
    let textOpen = false;
    let textBuffer = "";
    let thinkingOpen = false;
    let thinkingBuffer = "";
    let sawFinishReason = false;
    const toolBuilders = new Map;
    const toolOrder = [];
    for await (const raw of readSse(response)) {
      const chunk = raw;
      if (chunk.id && !id)
        id = chunk.id;
      if (chunk.usage) {
        if (chunk.usage.prompt_tokens !== undefined) {
          inputTokens = chunk.usage.prompt_tokens;
        }
        if (chunk.usage.completion_tokens !== undefined) {
          outputTokens = chunk.usage.completion_tokens;
        }
      }
      const choice = chunk.choices?.[0];
      if (!choice)
        continue;
      const delta = choice.delta;
      if (delta) {
        const reasoning = delta.reasoning_content;
        if (typeof reasoning === "string" && reasoning.length > 0) {
          if (!thinkingOpen)
            thinkingOpen = true;
          thinkingBuffer += reasoning;
          yield { type: "thinking-delta", text: reasoning };
        }
        const content = delta.content;
        if (typeof content === "string" && content.length > 0) {
          if (thinkingOpen) {
            yield { type: "thinking-end", text: thinkingBuffer };
            thinkingOpen = false;
            thinkingBuffer = "";
          }
          if (!textOpen)
            textOpen = true;
          textBuffer += content;
          yield { type: "text-delta", text: content };
        }
        if (delta.tool_calls) {
          for (const tc of delta.tool_calls) {
            const idx = tc.index;
            let builder = toolBuilders.get(idx);
            if (!builder) {
              builder = {
                id: tc.id ?? "",
                name: tc.function?.name ?? "",
                argsBuffer: ""
              };
              toolBuilders.set(idx, builder);
              toolOrder.push(idx);
            }
            if (tc.id)
              builder.id = tc.id;
            if (tc.function?.name)
              builder.name = tc.function.name;
            if (tc.function?.arguments) {
              builder.argsBuffer += tc.function.arguments;
            }
          }
        }
      }
      if (choice.finish_reason) {
        stopReason = mapFinishReason(choice.finish_reason);
        sawFinishReason = true;
      }
    }
    if (!sawFinishReason) {
      throw new Error("Chat completions stream ended without finish_reason; response is truncated.");
    }
    if (textOpen) {
      yield { type: "text-end", text: textBuffer };
    }
    if (thinkingOpen) {
      yield { type: "thinking-end", text: thinkingBuffer };
    }
    for (const idx of toolOrder) {
      const builder = toolBuilders.get(idx);
      if (!builder)
        continue;
      yield {
        type: "tool-call",
        toolCallId: builder.id,
        toolName: builder.name,
        input: parseToolArguments(builder.argsBuffer)
      };
    }
    yield {
      type: "message-end",
      id,
      stopReason,
      usage: { inputTokens, outputTokens }
    };
  }
  serializeMessages(messages) {
    const wire = [];
    for (const msg of messages) {
      if (msg.role === "system") {
        wire.push({ role: "system", content: msg.content });
        continue;
      }
      if (msg.role === "user") {
        const content = typeof msg.content === "string" ? msg.content : msg.content.map((part) => part.text).join(`
`);
        wire.push({ role: "user", content });
        continue;
      }
      if (msg.role === "assistant") {
        const texts = [];
        const toolCalls = [];
        for (const part of msg.content) {
          if (part.type === "text") {
            texts.push(part.text);
          } else if (part.type === "tool-call") {
            toolCalls.push({
              id: part.toolCallId,
              type: "function",
              function: {
                name: part.toolName,
                arguments: JSON.stringify(part.input ?? {})
              }
            });
          }
        }
        const assistantMsg = {
          role: "assistant",
          content: texts.length > 0 ? texts.join(`
`) : null,
          ...toolCalls.length > 0 ? { tool_calls: toolCalls } : {}
        };
        wire.push(this.adaptAssistantWire(assistantMsg));
        continue;
      }
      for (const part of msg.content) {
        wire.push({
          role: "tool",
          tool_call_id: part.toolCallId,
          content: serializeToolOutput2(part.output)
        });
      }
    }
    return wire;
  }
  adaptAssistantWire(msg) {
    return msg;
  }
  applyThinking(body) {}
}

// src/models/google.ts
var GEMINI_MODELS = [
  "gemini-3.5-flash",
  "gemini-3.1-pro",
  "gemini-3.1-flash-lite",
  "gemini-3-flash"
];

class GeminiModel extends OpenAICompatibleModel {
  constructor(modelName, options) {
    const key = options?.apiKey ?? env.geminiApiKey;
    if (!key) {
      throw new Error("No Gemini API key found. Set GEMINI_API_KEY or pass apiKey.");
    }
    super(modelName, {
      apiKey: key,
      baseUrl: options?.baseUrl ?? "https://generativelanguage.googleapis.com/v1beta/openai",
      thinking: options?.thinking
    });
  }
  applyThinking(body) {
    if (this.thinking === "off")
      return;
    const effort = this.thinking === "minimal" || this.thinking === "low" ? "low" : this.thinking === "medium" ? "medium" : "high";
    body.reasoning_effort = effort;
  }
  async searchWeb(query, opts) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${this.modelName}:generateContent`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-goog-api-key": this.apiKey
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: query }] }],
        tools: [{ google_search: {} }]
      })
    });
    if (!response.ok) {
      throw new Error(`Gemini web_search failed (${response.status}): ${await response.text()}`);
    }
    const json = await response.json();
    const chunks = json.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (!Array.isArray(chunks))
      return [];
    const hits = [];
    const seen = new Set;
    for (const chunk of chunks) {
      const uri = chunk.web?.uri;
      if (!uri || seen.has(uri))
        continue;
      seen.add(uri);
      hits.push({ title: chunk.web?.title ?? uri, url: uri });
    }
    if (opts?.maxUses !== undefined)
      return hits.slice(0, opts.maxUses);
    return hits;
  }
}

// src/models/moonshot.ts
var MOONSHOT_MODELS = ["kimi-k2.6", "kimi-k2.5"];

class MoonshotModel extends OpenAICompatibleModel {
  constructor(modelName, options) {
    const key = options?.apiKey ?? env.moonshotApiKey;
    if (!key) {
      throw new Error("No Moonshot API key found. Set MOONSHOT_API_KEY or pass apiKey.");
    }
    super(modelName, {
      apiKey: key,
      baseUrl: options?.baseUrl ?? "https://api.moonshot.ai/v1",
      thinking: options?.thinking
    });
  }
  adaptAssistantWire(msg) {
    if (!msg.tool_calls)
      return msg;
    return { ...msg, reasoning_content: "" };
  }
  applyThinking(body) {
    if (this.thinking === "off")
      return;
    if (this.modelName.includes("k2.6")) {
      body.chat_template_kwargs = { thinking: { type: "enabled" } };
      return;
    }
    body.enable_thinking = true;
  }
  async searchWeb(query, opts) {
    const messages = [
      {
        role: "user",
        content: `Search the web for: ${query}. List the most relevant results with their URLs.`
      }
    ];
    const tools = [
      {
        type: "builtin_function",
        function: { name: "$web_search" }
      }
    ];
    let response = await this.chat(messages, tools);
    let choice = response.choices[0];
    for (let i = 0;i < 4; i++) {
      if (!choice)
        break;
      const toolCalls = choice.message.tool_calls;
      if (!toolCalls || toolCalls.length === 0)
        break;
      messages.push({
        role: "assistant",
        content: choice.message.content ?? "",
        reasoning_content: choice.message.reasoning_content ?? "",
        tool_calls: toolCalls
      });
      for (const call of toolCalls) {
        messages.push({
          role: "tool",
          tool_call_id: call.id,
          name: call.function.name,
          content: call.function.arguments
        });
      }
      response = await this.chat(messages, tools);
      choice = response.choices[0];
    }
    const text = choice?.message.content ?? "";
    const hits = [];
    const seen = new Set;
    const urlRegex = /https?:\/\/[^\s)\]>"']+/g;
    for (const raw of text.match(urlRegex) ?? []) {
      const url = raw.replace(/[.,;:!?]+$/, "");
      if (seen.has(url))
        continue;
      seen.add(url);
      hits.push({ title: url, url });
    }
    if (opts?.maxUses !== undefined)
      return hits.slice(0, opts.maxUses);
    return hits;
  }
  async chat(messages, tools) {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.modelName,
        messages,
        tools
      })
    });
    if (!response.ok) {
      throw new Error(`Moonshot web_search failed (${response.status}): ${await response.text()}`);
    }
    return await response.json();
  }
}

// src/models/openai-codex-auth.ts
import { chmod, mkdir, readFile, rm, writeFile } from "fs/promises";
import { homedir } from "os";
import { dirname, join, resolve } from "path";
var CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann";
var CODEX_TOKEN_URL = "https://auth.openai.com/oauth/token";
var CHATGPT_AUTH_CLAIM = "https://api.openai.com/auth";
var DEFAULT_CODEX_BASE_URL = "https://chatgpt.com/backend-api/codex";
function expandPath(path) {
  if (path === "~")
    return homedir();
  if (path.startsWith("~/"))
    return join(homedir(), path.slice(2));
  return path;
}
function defaultAuthFiles() {
  const files = [];
  const explicit = env.openaiCodexAuthFile;
  if (explicit)
    files.push(expandPath(explicit));
  const codexHome = env.codexHome;
  if (codexHome)
    files.push(join(expandPath(codexHome), "auth.json"));
  files.push(join(homedir(), ".codex", "auth.json"));
  files.push(join(homedir(), ".drone", "openai-codex-auth.json"));
  return files;
}
function parseJwtPayload(token) {
  const [, payload] = token.split(".");
  if (!payload)
    return;
  try {
    const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(normalized.length + (4 - normalized.length % 4) % 4, "=");
    return JSON.parse(Buffer.from(padded, "base64").toString("utf8"));
  } catch {
    return;
  }
}
function jwtExpiresSoon(token) {
  const payload = parseJwtPayload(token);
  const exp = typeof payload?.exp === "number" ? payload.exp : undefined;
  if (exp === undefined)
    return false;
  return exp * 1000 <= Date.now() + 60000;
}
function extractRawIdToken(tokens) {
  if (typeof tokens.id_token === "string")
    return tokens.id_token;
  return tokens.id_token?.raw_jwt;
}
function extractAccountId(tokens) {
  if (tokens.account_id)
    return tokens.account_id;
  if (!tokens.access_token)
    return;
  const payload = parseJwtPayload(tokens.access_token);
  const auth = payload?.[CHATGPT_AUTH_CLAIM];
  if (typeof auth !== "object" || auth === null)
    return;
  const accountId = auth.chatgpt_account_id;
  return typeof accountId === "string" && accountId.length > 0 ? accountId : undefined;
}
function extractFedrampFlag(tokens) {
  const token = tokens.access_token ?? extractRawIdToken(tokens);
  if (!token)
    return false;
  const payload = parseJwtPayload(token);
  const auth = payload?.[CHATGPT_AUTH_CLAIM];
  if (typeof auth !== "object" || auth === null)
    return false;
  return auth.chatgpt_account_is_fedramp === true;
}
async function readJson(path) {
  const raw = await readFile(path, "utf8");
  return JSON.parse(raw);
}
async function writeJson(path, data) {
  await mkdir(dirname(path), { recursive: true, mode: 448 });
  await writeFile(path, `${JSON.stringify(data, null, 2)}
`, "utf8");
  await chmod(path, 384);
}
function sleep(ms) {
  return new Promise((resolve2) => setTimeout(resolve2, ms));
}
async function withAuthFileLock(authFile, fn) {
  const lockDir = `${authFile}.lock`;
  const deadline = Date.now() + 1e4;
  while (true) {
    try {
      await mkdir(lockDir, { mode: 448 });
      break;
    } catch (error) {
      const code = typeof error === "object" && error !== null && "code" in error ? error.code : undefined;
      if (code !== "EEXIST" || Date.now() >= deadline)
        throw error;
      await sleep(100);
    }
  }
  try {
    return await fn();
  } finally {
    await rm(lockDir, { recursive: true, force: true });
  }
}
async function findAuthFile(authFile) {
  if (authFile)
    return resolve(expandPath(authFile));
  for (const candidate of defaultAuthFiles()) {
    try {
      const data = await readJson(candidate);
      if (data.tokens?.access_token && data.tokens.refresh_token) {
        return candidate;
      }
    } catch {}
  }
  throw new Error('No OpenAI Codex auth found. Run `codex login` locally or pass auth: { type: "codex", authFile }.');
}
async function refreshCodexTokens(refreshToken) {
  const response = await fetch(CODEX_TOKEN_URL, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: CODEX_CLIENT_ID
    })
  });
  if (!response.ok) {
    throw new Error(`OpenAI Codex token refresh failed (${response.status}): ${await response.text()}`);
  }
  const json = await response.json();
  if (!json.access_token || !json.refresh_token) {
    throw new Error("OpenAI Codex token refresh response was missing tokens.");
  }
  return {
    id_token: json.id_token,
    access_token: json.access_token,
    refresh_token: json.refresh_token,
    account_id: extractAccountId({ access_token: json.access_token })
  };
}

class OpenAICodexAuth {
  authFile;
  baseUrl;
  constructor(options) {
    this.authFile = options.authFile;
    this.baseUrl = (options.baseUrl ?? DEFAULT_CODEX_BASE_URL).replace(/\/+$/, "");
  }
  async getHeaders() {
    const authFile = await findAuthFile(this.authFile);
    this.authFile = authFile;
    let auth = await readJson(authFile);
    let tokens = auth.tokens;
    if (!tokens?.access_token || !tokens.refresh_token) {
      throw new Error(`OpenAI Codex auth file at ${authFile} does not contain ChatGPT OAuth tokens.`);
    }
    if (jwtExpiresSoon(tokens.access_token)) {
      auth = await withAuthFileLock(authFile, async () => {
        const latest = await readJson(authFile);
        const latestTokens = latest.tokens;
        if (!latestTokens?.access_token || !latestTokens.refresh_token) {
          throw new Error(`OpenAI Codex auth file at ${authFile} does not contain ChatGPT OAuth tokens.`);
        }
        if (!jwtExpiresSoon(latestTokens.access_token))
          return latest;
        const refreshedTokens = await refreshCodexTokens(latestTokens.refresh_token);
        latest.tokens = refreshedTokens;
        latest.auth_mode = "chatgpt";
        latest.last_refresh = new Date().toISOString();
        await writeJson(authFile, latest);
        return latest;
      });
      tokens = auth.tokens;
      if (!tokens?.access_token || !tokens.refresh_token) {
        throw new Error(`OpenAI Codex auth file at ${authFile} does not contain ChatGPT OAuth tokens after refresh.`);
      }
    }
    const accountId = extractAccountId(tokens);
    if (!accountId) {
      throw new Error("OpenAI Codex auth token does not contain account id.");
    }
    return {
      authorization: `Bearer ${tokens.access_token}`,
      accountId,
      isFedrampAccount: extractFedrampFlag(tokens)
    };
  }
}

// src/models/openai.ts
var OPENAI_MODELS = [
  "gpt-5.5",
  "gpt-5.4",
  "gpt-5.4-mini",
  "gpt-5.4-nano",
  "gpt-5.3-codex"
];
function serializeToolOutput3(output) {
  if (output === undefined || output === null)
    return "";
  if (typeof output === "string")
    return output;
  return JSON.stringify(output);
}
function parseToolArguments2(raw) {
  if (!raw)
    return {};
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}
function sanitizeResponsesId(id) {
  const normalized = id.replace(/[^a-zA-Z0-9_-]/g, "_").replace(/_+$/, "");
  return normalized.slice(0, 64) || "item";
}
function responsesMessageInput(messages) {
  const instructions = [];
  const input = [];
  let messageIndex = 0;
  for (const msg of messages) {
    if (msg.role === "system") {
      instructions.push(msg.content);
      continue;
    }
    if (msg.role === "user") {
      const text = typeof msg.content === "string" ? msg.content : msg.content.map((part) => part.text).join(`
`);
      input.push({ role: "user", content: [{ type: "input_text", text }] });
      continue;
    }
    if (msg.role === "assistant") {
      for (const part of msg.content) {
        if (part.type === "text") {
          input.push({
            type: "message",
            role: "assistant",
            content: [
              { type: "output_text", text: part.text, annotations: [] }
            ],
            status: "completed",
            id: `msg_${messageIndex}`
          });
        } else if (part.type === "tool-call") {
          input.push({
            type: "function_call",
            id: `fc_${sanitizeResponsesId(part.toolCallId)}`,
            call_id: part.toolCallId,
            name: part.toolName,
            arguments: JSON.stringify(part.input ?? {})
          });
        }
      }
      messageIndex++;
      continue;
    }
    for (const part of msg.content) {
      input.push({
        type: "function_call_output",
        call_id: part.toolCallId,
        output: serializeToolOutput3(part.output)
      });
    }
  }
  return {
    instructions: instructions.length > 0 ? instructions.join(`

`) : undefined,
    input
  };
}
function responsesTools(tools) {
  if (!tools || tools.length === 0)
    return;
  return tools.map((tool) => ({
    type: "function",
    name: tool.name,
    description: tool.description,
    parameters: tool.toJsonSchema()
  }));
}
function mapResponsesStatus(status) {
  switch (status) {
    case "incomplete":
      return "max_tokens";
    case "failed":
    case "cancelled":
      return "refusal";
    default:
      return "end_turn";
  }
}

class OpenAIModel extends OpenAICompatibleModel {
  codexAuth;
  constructor(modelName, options) {
    const auth = options?.auth ?? { type: "apiKey" };
    const key = auth.type === "apiKey" ? auth.apiKey ?? env.openaiApiKey ?? "" : "";
    if (auth.type === "apiKey" && !key) {
      throw new Error('No OpenAI API key found. Set OPENAI_API_KEY or pass auth: { type: "apiKey", apiKey }.');
    }
    super(modelName, {
      apiKey: key,
      baseUrl: options?.baseUrl ?? "https://api.openai.com/v1",
      thinking: options?.thinking
    });
    if (auth.type === "codex") {
      this.codexAuth = new OpenAICodexAuth({
        type: "codex",
        authFile: auth.authFile,
        baseUrl: options?.baseUrl
      });
      this.baseUrl = this.codexAuth.baseUrl;
    }
  }
  async* streamMessage(params) {
    if (this.codexAuth || isResponsesOnlyModel(this.modelName)) {
      yield* this.streamResponses(params);
      return;
    }
    yield* super.streamMessage(params);
  }
  applyThinking(body) {
    if (this.thinking === "off")
      return;
    body.reasoning_effort = this.thinking === "xhigh" ? "high" : this.thinking;
  }
  async searchWeb(query, opts) {
    if (this.codexAuth) {
      const json2 = await this.fetchResponsesBuffered({
        model: this.modelName,
        stream: true,
        store: false,
        tools: [{ type: "web_search" }],
        input: [
          {
            role: "user",
            content: [
              { type: "input_text", text: `Search the web for: ${query}` }
            ]
          }
        ],
        instructions: "You are a helpful assistant."
      });
      const hits2 = extractSearchHits(json2);
      if (hits2.length > 0) {
        return opts?.maxUses !== undefined ? hits2.slice(0, opts.maxUses) : hits2;
      }
      const answer = extractAnswerText(json2);
      if (!answer)
        return [];
      const result = [
        { title: "Web search answer", text: answer }
      ];
      return opts?.maxUses !== undefined ? result.slice(0, opts.maxUses) : result;
    }
    const response = await fetch(`${this.baseUrl}/responses`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.modelName,
        tools: [{ type: "web_search_preview" }],
        input: `Search the web for: ${query}`
      })
    });
    if (!response.ok) {
      throw new Error(`OpenAI web_search failed (${response.status}): ${await response.text()}`);
    }
    const json = await response.json();
    const hits = [];
    const seen = new Set;
    for (const item of json.output) {
      if (item.type !== "message")
        continue;
      const parts = item.content;
      if (!Array.isArray(parts))
        continue;
      for (const part of parts) {
        const annotations = part.annotations;
        if (!Array.isArray(annotations))
          continue;
        for (const ann of annotations) {
          if (ann.type !== "url_citation")
            continue;
          if (!ann.url || seen.has(ann.url))
            continue;
          seen.add(ann.url);
          hits.push({ title: ann.title ?? ann.url, url: ann.url });
        }
      }
    }
    if (opts?.maxUses !== undefined)
      return hits.slice(0, opts.maxUses);
    return hits;
  }
  async* streamResponses(params) {
    if (this.codexAuth && params.maxTokens !== undefined) {
      throw new Error("OpenAI Codex auth does not support maxTokens.");
    }
    const { messages, tools, maxTokens, signal } = params;
    const { instructions, input } = responsesMessageInput(messages);
    const wireTools = responsesTools(tools);
    const body = {
      model: this.modelName,
      input,
      store: false,
      stream: true
    };
    body.instructions = instructions ?? "You are a helpful assistant.";
    if (wireTools)
      body.tools = wireTools;
    if (!this.codexAuth && maxTokens !== undefined) {
      body.max_output_tokens = maxTokens;
    }
    if (this.thinking !== "off") {
      body.reasoning = { effort: this.thinking };
    }
    const { url, headers } = await this.responsesEndpoint();
    const response = await fetch(url, {
      method: "POST",
      headers: { ...headers, accept: "text/event-stream" },
      body: JSON.stringify(body),
      signal
    });
    if (!response.ok) {
      throw new Error(`OpenAI Responses error ${response.status}: ${await response.text()}`);
    }
    let id = "";
    let stopReason = "end_turn";
    let inputTokens = 0;
    let outputTokens = 0;
    let sawToolCall = false;
    let sawCompleted = false;
    let textOpen = false;
    let thinkingOpen = false;
    const toolByItemId = new Map;
    const itemOrder = [];
    for await (const raw of readSse(response)) {
      const event = raw;
      if (event.type === "response.created") {
        if (event.response.id)
          id = event.response.id;
        continue;
      }
      if (event.type === "response.output_item.added") {
        const item = event.item;
        if (item.type === "function_call" && item.id) {
          toolByItemId.set(item.id, {
            callId: item.call_id ?? item.id,
            name: item.name ?? "",
            argsBuffer: ""
          });
          itemOrder.push(item.id);
        }
        continue;
      }
      if (event.type === "response.output_text.delta") {
        if (!textOpen)
          textOpen = true;
        yield { type: "text-delta", text: event.delta };
        continue;
      }
      if (event.type === "response.output_text.done") {
        if (textOpen) {
          yield { type: "text-end", text: event.text };
          textOpen = false;
        }
        continue;
      }
      if (event.type === "response.reasoning_summary_text.delta") {
        if (!thinkingOpen)
          thinkingOpen = true;
        yield { type: "thinking-delta", text: event.delta };
        continue;
      }
      if (event.type === "response.reasoning_summary_text.done") {
        if (thinkingOpen) {
          yield { type: "thinking-end", text: event.text };
          thinkingOpen = false;
        }
        continue;
      }
      if (event.type === "response.function_call_arguments.delta") {
        if (event.item_id) {
          const builder = toolByItemId.get(event.item_id);
          if (builder)
            builder.argsBuffer += event.delta;
        }
        continue;
      }
      if (event.type === "response.function_call_arguments.done") {
        if (event.item_id) {
          const builder = toolByItemId.get(event.item_id);
          if (builder)
            builder.argsBuffer = event.arguments;
        }
        continue;
      }
      if (event.type === "response.output_item.done") {
        const item = event.item;
        if (item.type === "function_call") {
          sawToolCall = true;
          const callId = item.call_id ?? "";
          const matched = [...toolByItemId.values()].find((b) => b.callId === callId);
          const args = matched?.argsBuffer ?? item.arguments ?? "";
          yield {
            type: "tool-call",
            toolCallId: callId,
            toolName: item.name,
            input: parseToolArguments2(args)
          };
        }
        continue;
      }
      if (event.type === "response.completed") {
        sawCompleted = true;
        if (!id && event.response.id)
          id = event.response.id;
        stopReason = sawToolCall ? "tool_use" : mapResponsesStatus(event.response.status);
        inputTokens = event.response.usage?.input_tokens ?? inputTokens;
        outputTokens = event.response.usage?.output_tokens ?? outputTokens;
        continue;
      }
      if (event.type === "response.failed") {
        throw new Error(event.response?.error?.message ?? "OpenAI Responses stream failed.");
      }
    }
    if (!sawCompleted) {
      throw new Error("OpenAI Responses stream ended before response.completed; response is truncated.");
    }
    yield {
      type: "message-end",
      id,
      stopReason,
      usage: { inputTokens, outputTokens }
    };
  }
  async fetchResponsesBuffered(body) {
    const { url, headers } = await this.responsesEndpoint();
    const response = await fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      throw new Error(`OpenAI Responses error ${response.status}: ${await response.text()}`);
    }
    if (body.stream === true)
      return parseResponsesStream(await response.text());
    return await response.json();
  }
  async responsesEndpoint() {
    if (this.codexAuth) {
      const auth = await this.codexAuth.getHeaders();
      const headers = {
        authorization: auth.authorization,
        "chatgpt-account-id": auth.accountId,
        originator: "drone",
        "openai-beta": "responses=experimental",
        accept: "application/json",
        "content-type": "application/json"
      };
      if (auth.isFedrampAccount)
        headers["x-openai-fedramp"] = "true";
      return { url: `${this.codexAuth.baseUrl}/responses`, headers };
    }
    return {
      url: `${this.baseUrl}/responses`,
      headers: {
        authorization: `Bearer ${this.apiKey}`,
        accept: "application/json",
        "content-type": "application/json"
      }
    };
  }
}
function isResponsesOnlyModel(modelName) {
  return modelName.includes("codex");
}
function parseResponsesStream(raw) {
  const output = [];
  let completed;
  for (const event of parseSseEvents(raw)) {
    if (event.type === "response.output_item.done") {
      output.push(event.item);
      continue;
    }
    if (event.type === "response.completed") {
      completed = event.response;
      continue;
    }
    if (event.type === "response.failed") {
      throw new Error(event.response?.error?.message ?? "OpenAI Codex response failed.");
    }
  }
  if (!completed) {
    throw new Error("OpenAI Codex stream ended before response.completed.");
  }
  return {
    ...completed,
    output: completed.output && completed.output.length > 0 ? completed.output : output
  };
}
function parseSseEvents(raw) {
  const events = [];
  for (const block of raw.split(/\r?\n\r?\n/)) {
    const dataLines = block.split(/\r?\n/).filter((line) => line.startsWith("data:")).map((line) => line.slice("data:".length).trimStart());
    if (dataLines.length === 0)
      continue;
    const data = dataLines.join(`
`);
    if (data === "[DONE]")
      continue;
    try {
      events.push(JSON.parse(data));
    } catch {}
  }
  return events;
}
function extractAnswerText(json) {
  const parts = [];
  for (const item of json.output ?? []) {
    if (item.type !== "message")
      continue;
    for (const part of item.content ?? []) {
      if (typeof part.text === "string")
        parts.push(part.text);
    }
  }
  return parts.join("").trim();
}
function extractSearchHits(json) {
  const hits = [];
  const seen = new Set;
  for (const item of json.output ?? []) {
    if (item.type !== "message")
      continue;
    for (const part of item.content ?? []) {
      const annotations = part.annotations;
      if (!Array.isArray(annotations))
        continue;
      for (const ann of annotations) {
        if (ann.type !== "url_citation")
          continue;
        if (!ann.url || seen.has(ann.url))
          continue;
        seen.add(ann.url);
        hits.push({ title: ann.title ?? ann.url, url: ann.url });
      }
    }
  }
  return hits;
}
export {
  OpenAIModel,
  OpenAICompatibleModel,
  OPENAI_MODELS,
  MoonshotModel,
  MOONSHOT_MODELS,
  GeminiModel,
  GEMINI_MODELS,
  AnthropicModel,
  ANTHROPIC_MODELS
};
