type OpenAICodexAuthOptions = {
    type: 'codex';
    authFile?: string;
    baseUrl?: string;
};
type CodexAuthHeaders = {
    authorization: string;
    accountId: string;
    isFedrampAccount: boolean;
};
declare class OpenAICodexAuth {
    private authFile?;
    readonly baseUrl: string;
    constructor(options: OpenAICodexAuthOptions);
    getHeaders(): Promise<CodexAuthHeaders>;
}
export { OpenAICodexAuth, type CodexAuthHeaders, type OpenAICodexAuthOptions };
