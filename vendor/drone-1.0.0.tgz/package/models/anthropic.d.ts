import { Model, type CreateMessageParams, type LiteralUnion, type ModelStreamEvent, type SearchHit, type SearchOptions, type ThinkingLevel } from '../core';
declare const ANTHROPIC_MODELS: readonly ["claude-opus-4-7", "claude-opus-4-6", "claude-sonnet-4-6", "claude-sonnet-4-5", "claude-haiku-4-5"];
type AnthropicModelName = LiteralUnion<(typeof ANTHROPIC_MODELS)[number]>;
declare class AnthropicModel extends Model {
    modelName: string;
    apiKey: string;
    thinking: ThinkingLevel;
    constructor(modelName: AnthropicModelName, options?: {
        apiKey?: string;
        thinking?: ThinkingLevel;
    });
    streamMessage(params: CreateMessageParams): AsyncIterable<ModelStreamEvent>;
    searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
}
export { AnthropicModel, ANTHROPIC_MODELS };
