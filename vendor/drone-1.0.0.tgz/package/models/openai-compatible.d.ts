import { Model, type CreateMessageParams, type Message, type ModelStreamEvent, type ThinkingLevel } from '../core';
interface OpenAIToolCall {
    id: string;
    type: 'function';
    function: {
        name: string;
        arguments: string;
    };
}
interface OpenAIAssistantWireMessage {
    role: 'assistant';
    content: string | null;
    tool_calls?: OpenAIToolCall[];
}
type OpenAIWireMessage = {
    role: 'system';
    content: string;
} | {
    role: 'user';
    content: string;
} | OpenAIAssistantWireMessage | {
    role: 'tool';
    tool_call_id: string;
    content: string;
};
declare abstract class OpenAICompatibleModel extends Model {
    modelName: string;
    apiKey: string;
    baseUrl: string;
    thinking: ThinkingLevel;
    protected constructor(modelName: string, options: {
        apiKey: string;
        baseUrl: string;
        thinking?: ThinkingLevel;
    });
    streamMessage(params: CreateMessageParams): AsyncIterable<ModelStreamEvent>;
    protected serializeMessages(messages: Message[]): OpenAIWireMessage[];
    protected adaptAssistantWire(msg: OpenAIAssistantWireMessage): OpenAIAssistantWireMessage;
    protected applyThinking(body: Record<string, unknown>): void;
}
export { OpenAICompatibleModel, type OpenAIAssistantWireMessage };
