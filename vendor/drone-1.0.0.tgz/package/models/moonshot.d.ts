import type { LiteralUnion, SearchHit, SearchOptions, ThinkingLevel } from '../core';
import { OpenAICompatibleModel, type OpenAIAssistantWireMessage } from './openai-compatible';
declare const MOONSHOT_MODELS: readonly ["kimi-k2.6", "kimi-k2.5"];
type MoonshotModelName = LiteralUnion<(typeof MOONSHOT_MODELS)[number]>;
declare class MoonshotModel extends OpenAICompatibleModel {
    constructor(modelName: MoonshotModelName, options?: {
        apiKey?: string;
        baseUrl?: string;
        thinking?: ThinkingLevel;
    });
    protected adaptAssistantWire(msg: OpenAIAssistantWireMessage): OpenAIAssistantWireMessage;
    protected applyThinking(body: Record<string, unknown>): void;
    searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
    private chat;
}
export { MoonshotModel, MOONSHOT_MODELS };
