import type { LiteralUnion, SearchHit, SearchOptions, ThinkingLevel } from '../core';
import { OpenAICompatibleModel } from './openai-compatible';
declare const GEMINI_MODELS: readonly ["gemini-3.5-flash", "gemini-3.1-pro", "gemini-3.1-flash-lite", "gemini-3-flash"];
type GeminiModelName = LiteralUnion<(typeof GEMINI_MODELS)[number]>;
declare class GeminiModel extends OpenAICompatibleModel {
    constructor(modelName: GeminiModelName, options?: {
        apiKey?: string;
        baseUrl?: string;
        thinking?: ThinkingLevel;
    });
    protected applyThinking(body: Record<string, unknown>): void;
    searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
}
export { GeminiModel, GEMINI_MODELS };
