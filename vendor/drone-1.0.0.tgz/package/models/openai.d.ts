import type { CreateMessageParams, LiteralUnion, ModelStreamEvent, SearchHit, SearchOptions, ThinkingLevel } from '../core';
import { OpenAICompatibleModel } from './openai-compatible';
declare const OPENAI_MODELS: readonly ["gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano", "gpt-5.3-codex"];
type OpenAIModelName = LiteralUnion<(typeof OPENAI_MODELS)[number]>;
type OpenAIApiKeyAuthOptions = {
    type: 'apiKey';
    apiKey?: string;
};
type OpenAICodexAuthModelOptions = {
    type: 'codex';
    authFile?: string;
};
type OpenAIAuthOptions = OpenAIApiKeyAuthOptions | OpenAICodexAuthModelOptions;
type OpenAIModelOptions = {
    auth?: OpenAIAuthOptions;
    baseUrl?: string;
    thinking?: ThinkingLevel;
};
declare class OpenAIModel extends OpenAICompatibleModel {
    private codexAuth?;
    constructor(modelName: OpenAIModelName, options?: OpenAIModelOptions);
    streamMessage(params: CreateMessageParams): AsyncIterable<ModelStreamEvent>;
    protected applyThinking(body: Record<string, unknown>): void;
    searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
    private streamResponses;
    private fetchResponsesBuffered;
    private responsesEndpoint;
}
export { OpenAIModel, OPENAI_MODELS, type OpenAIAuthOptions, type OpenAIModelOptions, };
