import { z } from 'zod';
import { Tool } from '../core';
declare const webSearch: Tool<z.ZodObject<{
    query: z.ZodString;
    allowed_domains: z.ZodOptional<z.ZodArray<z.ZodString>>;
    blocked_domains: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>, import("../core").SearchHit[]>;
declare const webFetch: Tool<z.ZodObject<{
    url: z.ZodURL;
    prompt: z.ZodString;
}, z.core.$strip>, string>;
declare const readFile: Tool<z.ZodObject<{
    path: z.ZodString;
    offset: z.ZodOptional<z.ZodNumber>;
    limit: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>, string>;
declare const writeFile: Tool<z.ZodObject<{
    path: z.ZodString;
    content: z.ZodString;
}, z.core.$strip>, string>;
declare const editFile: Tool<z.ZodObject<{
    path: z.ZodString;
    edits: z.ZodArray<z.ZodObject<{
        old_text: z.ZodString;
        new_text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>, string>;
declare const bash: Tool<z.ZodObject<{
    command: z.ZodString;
    timeout: z.ZodOptional<z.ZodNumber>;
    workdir: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, string>;
export { bash, editFile, readFile, webFetch, webSearch, writeFile };
