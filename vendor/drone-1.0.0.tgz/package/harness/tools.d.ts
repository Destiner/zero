import { z } from 'zod';
import { Tool } from '../core';
declare const webSearch: Tool<z.ZodObject<{
    query: z.ZodString;
    allowed_domains: z.ZodOptional<z.ZodArray<z.ZodString>>;
    blocked_domains: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>, import("../core").SearchHit[]>;
declare const webFetch: Tool<z.ZodObject<{
    url: z.ZodURL;
    prompt: z.ZodString;
}, z.core.$strip>, string>;
export { webSearch, webFetch };
