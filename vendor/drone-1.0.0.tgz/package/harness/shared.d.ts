import { Tool, type SearchHit, type ToolContext } from '../core';
declare function notImplemented(name: string): () => Promise<never>;
declare function runWebSearch(ctx: ToolContext, args: {
    query: string;
    allowed_domains?: string[];
    blocked_domains?: string[];
}): Promise<SearchHit[]>;
declare function runWebFetch(ctx: ToolContext, args: {
    url: string;
    prompt: string;
}): Promise<string>;
declare function serializeShellResult(stdout: string, stderr: string, exitCode: number): string;
declare function runShell({ cmd, timeout, workdir, shell, login, }: {
    cmd: string;
    timeout?: number;
    workdir?: string;
    shell?: string;
    login?: boolean;
}): Promise<string>;
declare function readFile(filePath: string, opts?: {
    offset?: number;
    limit?: number;
}): Promise<string>;
type ExactReplacement = {
    oldString: string;
    newString: string;
};
declare function applyExactReplacements(filePath: string, replacements: ExactReplacement[]): Promise<number>;
declare function applyPatchText(patch: string, opts?: {
    cwd?: string;
}): Promise<string>;
declare function createToolSearch(): Tool;
export { applyExactReplacements, applyPatchText, createToolSearch, notImplemented, readFile, runShell, runWebFetch, runWebSearch, serializeShellResult, };
