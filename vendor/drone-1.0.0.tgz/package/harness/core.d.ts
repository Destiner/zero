import type { Tool } from '../core';
declare class Harness {
    system: string;
    tools: Tool[];
    constructor(system: string, tools: Tool[]);
}
export { Harness };
