import { Harness } from './core';
declare const harness: Harness;
export default harness;
