declare class Skill {
    name: string;
    description: string;
    content: string;
    constructor({ name, description, content, }: {
        name: string;
        description: string;
        content: string;
    });
}
export { Skill };
