import type { TextPart, ThinkingPart, ToolCallPart } from './message';
import type { StopReason } from './tool';
type ModelStreamEvent = {
    type: 'text-delta';
    text: string;
} | {
    type: 'text-end';
    text: string;
} | {
    type: 'thinking-delta';
    text: string;
} | {
    type: 'thinking-end';
    text: string;
    signature?: string;
    redactedData?: string;
} | {
    type: 'tool-call';
    toolCallId: string;
    toolName: string;
    input: unknown;
} | {
    type: 'message-end';
    id: string;
    stopReason: StopReason;
    usage: {
        inputTokens: number;
        outputTokens: number;
    };
};
type AssistantContentPart = TextPart | ThinkingPart | ToolCallPart;
declare function readSse(response: Response): AsyncGenerator<unknown>;
export { readSse, type AssistantContentPart, type ModelStreamEvent };
