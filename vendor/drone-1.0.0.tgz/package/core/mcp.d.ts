import type { Tool } from './tool';
interface McpClient {
    connect(): Promise<Tool[]>;
    disconnect(): Promise<void>;
}
export type { McpClient };
