import type { Message, TextPart } from './message';
type TurnEvent = {
    type: 'message-start';
} | {
    type: 'text-delta';
    text: string;
} | {
    type: 'text';
    text: string;
} | {
    type: 'thinking-delta';
    text: string;
} | {
    type: 'thinking';
    text: string;
    signature?: string;
} | {
    type: 'tool-call';
    toolCallId: string;
    toolName: string;
    input: unknown;
} | {
    type: 'tool-result';
    toolCallId: string;
    toolName: string;
    output: unknown;
    isError: boolean;
} | {
    type: 'message-end';
    usage: {
        inputTokens: number;
        outputTokens: number;
    };
} | {
    type: 'turn-end';
} | {
    type: 'error';
    error: Error;
};
type TurnEmit = (event: TurnEvent) => void;
interface TurnRunContext {
    emit: TurnEmit;
    signal: AbortSignal;
}
type TurnRunner = (ctx: TurnRunContext) => Promise<Message[]>;
declare class Turn implements AsyncIterable<TurnEvent>, PromiseLike<Message[]> {
    private queue;
    private waiters;
    private ended;
    private iterated;
    private resultPromise;
    private abortController;
    constructor(runner: TurnRunner);
    private emit;
    private close;
    abort(reason?: string): void;
    [Symbol.asyncIterator](): AsyncIterator<TurnEvent>;
    then<TResult1 = Message[], TResult2 = never>(onfulfilled?: ((value: Message[]) => TResult1 | PromiseLike<TResult1>) | null | undefined, onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null | undefined): PromiseLike<TResult1 | TResult2>;
}
interface SessionInternals {
    send(prompt: string | TextPart[]): Turn;
    close(): Promise<void>;
}
declare class Session implements AsyncDisposable {
    private internals;
    private state;
    constructor(internals: SessionInternals, state: {
        messages: Message[];
    });
    get messages(): readonly Message[];
    send(prompt: string | TextPart[]): Turn;
    close(): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
export { Session, Turn, type SessionInternals, type TurnEmit, type TurnEvent, type TurnRunContext, type TurnRunner, };
