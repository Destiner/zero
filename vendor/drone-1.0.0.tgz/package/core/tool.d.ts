import { z } from 'zod';
import type { Message, TextPart, ThinkingPart, ToolCallPart } from './message';
type MaybePromise<T> = T | Promise<T>;
type StopReason = 'end_turn' | 'tool_use' | 'max_tokens' | 'stop_sequence' | 'pause_turn' | 'refusal';
interface SessionState {
    messages: Message[];
    store: Map<string, unknown>;
}
interface ToolRegistry {
    loaded(): Tool[];
    deferred(): Tool[];
    load(names: string[]): {
        loaded: Tool[];
        missing: string[];
    };
}
interface SearchHit {
    title: string;
    url?: string;
    pageAge?: string;
    text?: string;
}
interface SearchOptions {
    allowedDomains?: string[];
    blockedDomains?: string[];
    maxUses?: number;
}
interface CreateMessageParams {
    messages: Message[];
    tools?: Tool[];
    maxTokens?: number;
    signal?: AbortSignal;
}
interface CreateMessageResponse {
    id: string;
    content: (TextPart | ThinkingPart | ToolCallPart)[];
    stopReason: StopReason;
    usage: {
        inputTokens: number;
        outputTokens: number;
    };
}
interface ToolContext {
    complete(prompt: string): Promise<string>;
    searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
    session: SessionState;
    tools: ToolRegistry;
    cwd: string;
}
type ZodToolInit<TSchema extends z.ZodTypeAny, TResult> = {
    name: string;
    description: string;
    inputSchema: TSchema;
    execute: (input: z.infer<TSchema>, ctx: ToolContext) => MaybePromise<TResult>;
    deferred?: boolean;
};
type RawToolInit<TResult> = {
    name: string;
    description: string;
    jsonSchema: object;
    execute: (input: unknown, ctx: ToolContext) => MaybePromise<TResult>;
    deferred?: boolean;
};
declare class Tool<TSchema extends z.ZodTypeAny = z.ZodTypeAny, TResult = unknown> {
    name: string;
    description: string;
    inputSchema?: TSchema;
    jsonSchema?: object;
    execute: (input: unknown, ctx: ToolContext) => MaybePromise<TResult>;
    deferred: boolean;
    constructor(init: ZodToolInit<TSchema, TResult>);
    constructor(init: RawToolInit<TResult>);
    toJsonSchema(): object;
    parse(input: unknown): unknown;
}
declare function createRegistry(tools: Tool[]): ToolRegistry;
export { Tool, createRegistry, type CreateMessageParams, type CreateMessageResponse, type SearchHit, type SearchOptions, type SessionState, type StopReason, type ToolContext, type ToolRegistry, };
