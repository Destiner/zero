import type { Trigger, TriggerHandler } from '../triggers/core';
import type { McpClient } from './mcp';
import type { Message } from './message';
import type { Model } from './model';
import { Session } from './session';
import { Skill } from './skill';
import { Tool } from './tool';
declare class Agent {
    model: Model;
    prompt: string;
    tools: Tool[];
    skills: Skill[];
    mcp: McpClient[];
    cwd?: string;
    private registrations;
    private unsubs;
    constructor({ model, prompt, tools, skills, mcp, cwd, }: {
        model: Model;
        prompt: string;
        tools: Tool[];
        skills: Skill[];
        mcp?: McpClient[];
        cwd?: string;
    });
    on<T>(trigger: Trigger<T>, handler: TriggerHandler<T>): void;
    start(): Promise<void>;
    stop(): Promise<void>;
    buildSystem(allTools: Tool[]): string;
    private buildSkillTool;
    session(init?: {
        messages?: Message[];
        cwd?: string;
    }): Session;
}
export { Agent };
