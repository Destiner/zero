import type { ModelStreamEvent } from './stream';
import type { CreateMessageParams, CreateMessageResponse, SearchHit, SearchOptions } from './tool';
type LiteralUnion<T extends string> = T | (string & {});
type ThinkingLevel = 'off' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh';
declare abstract class Model {
    abstract streamMessage(params: CreateMessageParams): AsyncIterable<ModelStreamEvent>;
    abstract searchWeb(query: string, opts?: SearchOptions): Promise<SearchHit[]>;
    createMessage(params: CreateMessageParams): Promise<CreateMessageResponse>;
}
export { Model, type LiteralUnion, type ThinkingLevel };
